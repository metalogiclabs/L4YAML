import L4YAML.Proofs.Production.StreamAccum
#print axioms L4YAML.Proofs.StreamAccum.question_open_map
#print axioms L4YAML.Proofs.StreamAccum.accum_block_pending
#print axioms L4YAML.Proofs.StreamAccum.scan_content_gives_stream_v2
