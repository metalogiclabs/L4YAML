# Census dashboard — tree `63c29267`

latest item: 539 (2026-11-25)
mandate: step 12.3.4.2, by PAYING IN PLACE: every writer above declines into a field that is still disjunctive, so each can be turned from `Or.inr` to `Or.inl` on today's statements, one green item at a time, and the flip that follows is collapses and relays only. (1) (R3): `accum_block_on_noPending` 27037 writes `Or.inl` over the empty domain (`markedCols s' = []` from the dead register, item 508's lemma…
pins read: 114 (42 censuses)

## Directed censuses — how far each is from its goal, and what moves it

`left` is `|now − goal|`; `move` is what the guard enforces (a shrink-only pin that rises needs the owner's word); `status` HOLD is a reading kept at its goal by a gate.

| census | fields | open | done | hold | left, per open field |
|---|---:|---:|---:|---:|---|
| `CapstonePathAudit` | 3 | 3 | 0 | 0 | `on` 7, `off` 179, `unresolved` 67 |
| `OrTrueAudit` | 10 | 7 | 0 | 3 | `positions` 253, `PackAlt` 67, `PackAltG` 9, `conclusions` 9, `inrTrivial` 460, `unresolved` 8, `unreadable` 36 |
| `BlockDeferralClasses` | 9 | 7 | 0 | 2 | `entryKeyPack_of_dispatch` 9, `entryPropsKeyPack_of_dispatch` 9, `content_dispatch_routed` 25, `expectedPackResidue.decline` 70, `expectedPackResidue.uncond` 12, `relayState` 4, `apps` 3 |
| `GhostIndexCensus` | 3 | 3 | 0 | 0 | `ghost` 74, `snapshot` 9, `or` 139 |
| `DeadDeclarationCensus` | 3 | 3 | 0 | 0 | `B-roster` 3308, `A-orphan` 103, `unresolved` 5 |
| `RelaySupplyCensus` | 4 | 2 | 0 | 2 | `expectedTally.DECLINE` 234, `expectedSplitLanding.DECLINE` 214 |
| `ArmSpendCensus` | 1 | 1 | 0 | 0 | `DECLINE` 22 |
| `NarrowingWorthCensus` | 4 | 3 | 0 | 1 | `binders` 158, `byElab` 14, `hiddenOnly` 2 |
| `PremiseNecessityCensus` | 1 | 1 | 0 | 0 | `dead` 30 |
| `ValueLinePacks` | 1 | 1 | 0 | 0 | `punt` 16 |
| `ValueLineOrigins` | 1 | 1 | 0 | 0 | `punt` 4 |
| `RouteShapes` | 1 | 1 | 0 | 0 | `punt` 69 |
| `ScannerFlowOpenUnderRun` | 2 | 2 | 0 | 0 | `paid` 14, `owed` 14 |
| `SuffixGapAudit` | 3 | 2 | 0 | 1 | `broken` 1, `connected` 1 |
| `FreeSurfaceCensus` | 2 | 2 | 0 | 0 | `free` 17, `survivesBeta5` 2 |
| `DropDependents` | 3 | 2 | 0 | 1 | `expectedCensus.T` 32, `D` 4 |
| `ParkBill` | 6 | 4 | 0 | 2 | `sorried` 13, `arms` 1, `Tp` 39, `carried` 21 |
| `SurfaceSpanCensus` | 5 | 2 | 0 | 3 | `covered` 5, `uncovered` 5 |
| `ColumnWalkPrice` | 3 | 2 | 0 | 1 | `withSuffixLemma` 8, `missing` 8 |
| `scripts-ledger` | 1 | 0 | 1 | 0 | — |
| `GateVocabulary` | 1 | 0 | 0 | 1 | — |
| `OpenerFallbackReach` | 2 | 1 | 0 | 1 | `open` 18 |
| `ColumnAdvanceCensus` | 3 | 0 | 0 | 3 | — |
| `ConclusionObligationCensus` | 2 | 1 | 0 | 1 | `res` 51 |
| `ProducerDerivation` | 1 | 0 | 0 | 1 | — |
| `StreamCompositions` | 1 | 0 | 0 | 1 | — |
| `CarrierArmPrice` | 1 | 0 | 0 | 1 | — |
| `ParkGapCensus` | 1 | 0 | 0 | 1 | — |
| `ParkGapWidth` | 1 | 0 | 0 | 1 | — |
| `ParkGapProduction` | 1 | 0 | 0 | 1 | — |
| `DispatchPrice` | 1 | 0 | 0 | 1 | — |

**Totals:** directed=81 work=52 open=51 done=1 holds=29 left=5882 components=18 (shown, not summed)

A field marked ⊂ is a sub-count of another field of its census: shown, not counted.

### `CapstonePathAudit` — open=3 done=0 hold=0

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `on` | 7 | 0 | 7 | shrink-only | OPEN | parse_iff_grammar: no vacuous arm on a fact the capstone consumes | R12's (ω-pay-births) (d): the (2b) fixpoint pays the three ON park fields' `∨ PackAlt` (`pendingBlock.h_kslot`, `pendingBlockContent.h_kslot`, `pendingContent.h_vpack`) from the births, the `[map k]` resume fact and the `FlowStackK` carrier (items 510 / 513 → 140 sites / 19 decls) | item 439 (`CapstonePathAudit`: pins are shrink-only, ON re-pinned DOWN when an item pays or retires) |
| `off` | 179 | 0 | 179 | shrink-only | OPEN | the owner's `fix all ∨ True` — positions OFF the capstone's path | after ON reaches 0: each OFF position paid or retired by its own item (94 honest declines, 53 unread, 25 conclusions as of item 512) | item 439 (OFF is the residue the directive still names; the ON set is the risk) |
| `unresolved` | 67 | 0 | 67 | shrink-only | OPEN | positions the capstone-path classifier cannot class ON or OFF | read each (a nested position the walker does not follow) and teach the classifier the shape, or restate the site | item 439 (`unresolved` is the classifier's own refusal) |
| `on-drop` ⊂ | 3 | 0 | 3 | shrink-only | OPEN | ON positions at the on-drop producers' `else` arms | R12 (d): the dedent `else` arms pay from `markedCols_le_of_top` and the `[map k]` resume fact | items 439 / 493 / 498 |
| `on-relay` ⊂ | 4 | 0 | 4 | shrink-only | OPEN | ON positions relayed into the three park fields | mechanical once the fields are plain (the (2b) fixpoint's 120 relays) | items 439 / 501 |
| `on-via` ⊂ | 0 | 0 | 0 | hold | HOLD | ON positions supplied through a `VIA` lemma | none today; one appearing needs the owner's word | item 439 |
| `on-conclusion` ⊂ | 0 | 0 | 0 | hold | HOLD | ON conclusions `Or.inr trivial` proves | none today | item 439 |
| `off-unread` ⊂ | 55 | 0 | 55 | shrink-only | OPEN | OFF positions whose alternative no consumer reads | delete the alternative where it stands (nothing spends it) | item 439 |
| `off-conclusion` ⊂ | 19 | 0 | 19 | shrink-only | OPEN | OFF conclusions | narrow to the residue (`lake run restate -- narrow-conclusion` prices the relay damage first) | items 228 / 439 |
| `off-honest` ⊂ | 90 | 0 | 90 | shrink-only | OPEN | OFF positions with an honest decline today | each paid by its own item after ON closes | item 439 |

### `OrTrueAudit` — open=7 done=0 hold=3

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `positions` | 253 | 0 | 253 | shrink-only | OPEN | the owner's `fix all ∨ True` (item 394) | every `∨ True` / `∨ PackAlt _` / `∨ PackAltG _` position in an authored type retired: paid (the alternative made a real obligation), deleted, or restated; ON-path first (`CapstonePathAudit.on`), then OFF | item 395 (`OrTrueAudit`: the roster the retirement lane works from; shrink-only, a new position needs the owner's word) |
| `PackAlt` | 67 | 0 | 67 | shrink-only | OPEN | Rule 8: `PackAlt sc` is `True` under a name (item 311) | the pack lane: births paid at the producers (`entryKeyPack_of_dispatch`, `entryPropsKeyPack_of_dispatch`, `content_dispatch_routed`), then the park fields and their relays | items 311 / 395 |
| `PackAltG` | 9 | 0 | 9 | shrink-only | OPEN | Rule 8: `PackAltG g` is `True` under a name | the five `PackAltG` conclusions (item 511's roster), each a conclusion narrowing with its relay damage priced first | items 311 / 511 |
| `conclusions` | 9 | 0 | 9 | shrink-only | OPEN | a conclusion `Or.inr trivial` proves is not an obligation (§8) | narrow each `… ∨ True` conclusion to its residue (`lake run restate -- narrow-conclusion` prices the relay damage first, item 228) | items 227 / 228 / 395 |
| `inrTrivial` | 460 | 0 | 460 | shrink-only | OPEN | the `Or.inr trivial` writes — the vacuous arms taken | falls as positions are paid: a paid position leaves its writers nothing vacuous to write | item 395 |
| `unresolved` | 8 | 0 | 8 | shrink-only | OPEN | supply the census could not class | read each unresolved supplier (a pipe the walker does not see through) and teach the census the shape or restate the site | item 395 (`supply: … unresolved=`) |
| `True` ⊂ | 177 | 0 | 177 | shrink-only | OPEN | positions whose alternative is the literal `True` | as `positions` | item 395 |
| `top` ⊂ | 162 | 0 | 162 | shrink-only | OPEN | top-level `∨` positions | as `positions` | item 395 |
| `nested` ⊂ | 91 | 0 | 91 | shrink-only | OPEN | nested `∨` positions (inside `∀` / `∃` / `∧`) | as `positions` | item 395 |
| `unreadable` | 36 | 0 | 36 | shrink-only | OPEN | consumers the audit cannot read (instrument blindness) | teach the walker the shape (Rule 9 instrument item) — the owner's call whether this is owed | item 395 (`consumers: … unreadable=`) |
| `declined-only` | 0 | 0 | 0 | hold | HOLD | a position every supplier declines | the guard keeps it at 0 | item 395 |
| `never-supplied` | 0 | 0 | 0 | hold | HOLD | a position no caller supplies | the guard keeps it at 0 (item 396 deleted the last) | items 395 / 396 |
| `unused` | 0 | 0 | 0 | hold | HOLD | a consumer that takes the alternative and never reads it | the guard keeps it at 0 | item 395 |

### `BlockDeferralClasses` — open=7 done=0 hold=2

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `entryKeyPack_of_dispatch` | 7+2 | 0 | 9 | shrink-only | OPEN | the pack producers' `PackAlt` writes (`lake run check-pack-births`) | (d) births: the dedent arms pay through `markedCols_le_of_top` (item 498), the root births through the root closing lemma (item 508), the compact births through the `[map k]` resume fact (item 494) | items 431 / 500 / 512 (`a+b` = writes at the entry producer + its props twin's shared helper) |
| `entryPropsKeyPack_of_dispatch` | 7+2 | 0 | 9 | shrink-only | OPEN | the pack producers' `PackAlt` writes | as `entryKeyPack_of_dispatch` | items 431 / 500 / 512 |
| `content_dispatch_routed` | 25+0 | 0 | 25 | shrink-only | OPEN | the pack producers' `PackAlt` writes | the content dispatcher's 25 writes: each optional context (`h_keyctx`, `h_suffixctx`, `h_nodocctx`, `h_markerctx`, …) made plain at its callers | items 211 / 431 |
| `expectedPackResidue.decline` | 70 | 0 | 70 | shrink-only | OPEN | the pack residue flip (`lake run pack-census -- residue`) | every site that DECLINES a pack (`Or.inr`) in the residue tree; paid with the positions above | items 340 / 357 |
| `expectedPackResidue.uncond` | 12 | 0 | 12 | shrink-only | OPEN | the pack residue flip | the roots the flip must make unconditional — the producers that still hand a `PackAlt`-shaped fact down | items 340 / 357 |
| `expectedPackFlip.decline` ⊂ | 93 | 0 | 93 | shrink-only | OPEN | the pack flip: sites that decline the pack | as `expectedPackResidue.decline` — "this line is what each lane drives down" | items 312 / 340 |
| `expectedPackFlip.uncond` ⊂ | 24 | 0 | 24 | shrink-only | OPEN | the pack flip: roots to make unconditional | as `expectedPackResidue.uncond` | items 312 / 340 |
| `relay` | 0 | 0 | 0 | hold | HOLD | the pack flip: relays of a `PackAlt` the `False` flip still sees | the flip keeps it at 0 | items 312 / 340 |
| `relayState` | 4 | 0 | 4 | shrink-only | OPEN | the residue's transports | as `expectedPackFlip.relayState` | item 357 |
| `apps` | 3 | 0 | 3 | shrink-only | OPEN | step 12.3: the inline escape's remaining applications (two `noKeyContext` arms and the dead one) | empty the escape's domain: each input that reaches it takes a named arm | items 286 / 297 |
| `nokey` | 0 | 0 | 0 | hold | HOLD | accepted inputs the inline class keys nothing for | the census keeps it at 0 | item 286 |

### `GhostIndexCensus` — open=3 done=0 hold=0

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `ghost` | 74 | 0 | 74 | shrink-only | OPEN | Rule 8: no ghost index on the accumulation invariant | re-index each `List FrameLevel` / `List Nat` / `Array Bool` / `FrameTail` binder by a projection of `sc` (item 405: `h_kslot` over `markedCols sc`, 75 → 73) or add the missing field to `ScannerState`; #327's (i) for the sequence lane's outer frames | item 331 (`GhostIndexCensus`: the list to shrink; nothing may join it) |
| `snapshot` | 9 | 0 | 9 | shrink-only | OPEN | Rule 8: an `Option ScannerState` carried as an index | replace each snapshot by the projection the consumer reads off it | item 331 |
| `or` | 139 | 0 | 139 | shrink-only | OPEN | Rule 8: an `∨` inside a carrier field whose alternative restates state | falls with `OrTrueAudit.positions` — the per-field disjuncts are the same `∨ PackAlt` positions seen from the carrier | item 331 (`disjunct` class: the shape Rule 8 forbids) |

### `DeadDeclarationCensus` — open=3 done=0 hold=0

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `B-roster` | 3308 | 0 | 3308 | shrink-only | OPEN | Rule 1: no theorem without a capstone | each roster name is deleted (item 506 deleted 87 unreached scanner facts on the owner's word) or reached by a capstone chain (`DeadDeclarationRoster.lean` lists them) | items 476 / 477 (`lake run dead-census -- --check`) |
| `A-orphan` | 103 | 0 | 103 | shrink-only | OPEN | Rule 1: campaign declarations that no declaration anywhere consumes — built and never spent | deleted on the owner's ruling (`lake run dead-census` lists them by name), or spent by the consumer they were built for (a fold, a Rule 2 instantiation) | item 530 (`A-orphan`; `A-campaign` demoted to population) |
| `unresolved` | 5 | 0 | 5 | shrink-only | OPEN | Blueprint/04 rows whose root name resolves to no constant | fix the row in `Blueprint/04-capstones.md` / `scripts/blueprint-capstones.txt` or restore the constant | item 476 (`roots=… blueprint:N(unresolved=M)`) |

### `RelaySupplyCensus` — open=2 done=0 hold=2

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `expectedTally.DECLINE` | 234 | 0 | 234 | shrink-only | OPEN | supply of the `_ ∨ True` premises: an `Or.inr` written at the call site | paid when the premise's alternative is a real obligation the caller can meet; falls with `OrTrueAudit.positions` | item 212 (`RelaySupplyCensus`: `PAY` / `DECLINE` leaves) |
| `expectedSplitLanding.DECLINE` | 214 | 0 | 214 | shrink-only | OPEN | the leaves of `SPLIT` edges that decline (not counted by `expectedTally.DECLINE`, which reads top-level edges) | pay each leaf or hand its hypothesis back; falls with the `PackAlt` positions | item 216 |
| `DECLINE-closed` ⊂ | 96 | 0 | 96 | shrink-only | OPEN | declines closed with `trivial` | pay or hand the hypothesis back (`DECLINE-free`), then pay | item 314 |
| `DECLINE-free` ⊂ | 118 | 0 | 118 | shrink-only | OPEN | declines that hand their hypothesis back (relays of a `PackAlt`) | falls with the `PackAlt` positions | item 314 |
| `disagree` | 0 | 0 | 0 | hold | HOLD | the two split readings disagree | the census keeps it at 0 | item 216 |
| `dead` | 0 | 0 | 0 | hold | HOLD | decline pairs no live split reaches | the census keeps it at 0 | item 217 |

### `ArmSpendCensus` — open=1 done=0 hold=0

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `DECLINE` | 22 | 0 | 22 | shrink-only | OPEN | spend of the loose arm conjunct at its readers | as `RelaySupplyCensus.DECLINE`, over the arm family | item 224 |

### `NarrowingWorthCensus` — open=3 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `binders` | 158 | 0 | 158 | shrink-only | OPEN | the optional (`_ ∨ True`) binder population of `StreamAccum` — the denominator items 212–226 lacked | each binder narrowed to a load-bearing premise or deleted; falls with `OrTrueAudit.positions` | item 227 |
| `byElab` | 14 | 0 | 14 | shrink-only | OPEN | theorems whose conclusion is a no-op (provable without its hypotheses, §8) | restate or delete each (16 stand; none added since item 227) | item 227 (`expectedNoopTally`) |
| `hiddenOnly` | 2 | 0 | 2 | shrink-only | OPEN | optional binders hidden behind a definition the syntactic selector misses | unfold the definition at the selector (instrument) or restate the binder | item 227 §6 |
| `chainSplits` | 0 | 0 | 0 | hold | HOLD | arms a narrowing would collapse on a premise still unconditionally inhabited (a narrowing that buys nothing) | the census keeps it at 0 | item 227 §5 |

### `PremiseNecessityCensus` — open=1 done=0 hold=0

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `dead` | 30 | 0 | 30 | shrink-only | OPEN | binders no proof reads | the lane-stub binders of the `PackAlt` helpers go with `PackAlt`; the rest are deleted where they stand | item 226 (`expectedDead`: lane stubs) |

### `ValueLinePacks` — open=1 done=0 hold=0

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `punt` | 16 | 0 | 16 | shrink-only | OPEN | value-line pack writers that take the option's `True` arm | each punt replaced by the pack (route + frames + tail) the writer holds, or by a relay of its caller's | items 261 / 405 |

### `ValueLineOrigins` — open=1 done=0 hold=0

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `punt` | 4 | 0 | 4 | shrink-only | OPEN | value-line pack rows whose chain is born as a punt | as `ValueLinePacks.punt`, read at the origin | item 262 |

### `RouteShapes` — open=1 done=0 hold=0

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `punt` | 69 | 0 | 69 | shrink-only | OPEN | park closure slots that punt (`∨ True` closures) | one re-routing lemma per spine (`SSLComments ⇒ Stream`, `SBlockNode(_+1,blockOut) ⇒ Stream`, …) spent where the closure is built | item 248 |

### `ScannerFlowOpenUnderRun` — open=2 done=0 hold=0

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `paid` | 10 | 24 (= `cells`) | 14 | grow-only | OPEN | the under-run refusal at the break/EOF gate (items 66 / 172) | the carrier on the anchor (two declarations, `expectedWirePrice`), then each owed cell paid at its arm | item 172 (`cells=24 paid=N owed=M`) |
| `owed` | 14 | 0 | 14 | shrink-only | OPEN | the under-run gate | as `paid` | item 172 |

### `SuffixGapAudit` — open=2 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `broken` | 1 | 0 | 1 | shrink-only | OPEN | β.5: the one arm whose premises connect nothing (`scannerDrop`) | delete the arm (Row 12's six steps); every statement in `DropDependents.T` reproved or restated first | item 236 |
| `connected` | 183 | 184 (= `arms`) | 1 | grow-only | OPEN | every surface arm connects its source to its target | as `broken` | item 236 |
| `refuted` | 1 | 1 | 0 | hold | HOLD | `[211] l-yaml-stream` has no suffix lemma because the statement is false | β.5 (see `broken`) | item 235 / 236 |

### `FreeSurfaceCensus` — open=2 done=0 hold=0

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `free` | 17 | 0 | 17 | shrink-only | OPEN | theorems true without their hypotheses while the arm stands | β.5 retires the arm (15 stop being free); the `survivesBeta5` ones are restated | item 237 |
| `survivesBeta5` | 2 | 0 | 2 | shrink-only | OPEN | free theorems β.5 does not fix | restate each (its conclusion holds by `rfl`) | item 237 |

### `DropDependents` — open=2 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `expectedCensus.T` | 32 | 0 | 32 | shrink-only | OPEN | β.5's reproof bill: proofs running through the arm | each reproved without the arm (the `ParkBill` fixpoint names the ones that sorry) | item 238 |
| `D` | 4 | 0 | 4 | shrink-only | OPEN | β.5: direct constructions of the arm | `dropClose` and `close_with_ssl`'s `pendingFlow` branch (item 239's two restatements) and the two Tests-side exhibits | item 238 |
| `capstonesInT` ⊂ | 2 | 0 | 2 | shrink-only | OPEN | capstones whose proofs run through `scannerDrop` | β.5: the two capstones reproved without the arm | item 238 |
| `S` | 0 | 0 | 0 | hold | HOLD | statements that NAME the arm | the census keeps it at 0 (a name appearing would make the deletion a restatement) | item 238 |
| `expectedWideCensus.T` ⊂ | 27 | 0 | 27 | shrink-only | OPEN | the whole-tree twin of `T` (`lake run drop-sweep`) | as `expectedCensus.T` | item 238 |

### `ParkBill` — open=4 done=0 hold=2

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `sorried` | 13 | 0 | 13 | shrink-only | OPEN | β.5's retire flip: declarations that sorry at the fixpoint | each a reproof under the deleted arm; `lake run flip-beta5` re-reads it | item 240 / `ParkBill` |
| `arms` | 1 | 0 | 1 | shrink-only | OPEN | the escape still standing (`block_dispatch_deferred`) | empty the escape's domain (step 12.3): every input that reached it takes a named arm | `ParkBill.expectedArms` (`left=[block_dispatch_deferred]`) |
| `Tp` | 39 | 0 | 39 | shrink-only | OPEN | β.5's park bill: proofs running through `PendingNode.pendingFlow` | retire the park with the arm; each reproved | item 240 / `ParkBill` |
| `Dp` ⊂ | 11 | 0 | 11 | shrink-only | OPEN | direct constructions of the park | as `Tp` | item 240 |
| `capstonesInTp` ⊂ | 2 | 0 | 2 | shrink-only | OPEN | capstones riding the park | as `Tp` | item 240 |
| `Sp` | 0 | 0 | 0 | hold | HOLD | statements that name the park (the twin of `S=0`) | the census keeps it at 0 | item 240 |
| `carried` | 21 | 0 | 21 | shrink-only | OPEN | sorries the retire flip carries through its waves | as `sorried` | `ParkBill.expectedFixpoint` |
| `refused` | 0 | 0 | 0 | hold | HOLD | patches the flip refused | the flip keeps it at 0 | `ParkBill.expectedFixpoint` |

### `SurfaceSpanCensus` — open=2 done=0 hold=3

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `covered` | 74 | 79 (= `closure`) | 5 | grow-only | OPEN | the suffix law over the surface closure | a suffix lemma per uncovered production in `Proofs/Foundation/SurfaceSpanSupply.lean` | item 229 |
| `uncovered` | 5 | 0 | 5 | shrink-only | OPEN | the suffix law | as `covered` | item 229 |
| `elsewhere` | 0 | 0 | 0 | hold | HOLD | `BreakBetween` mentions outside the two residue modules | "the number this section exists to keep at zero" | item 229 §4 |
| `blocked` | 0 | 0 | 0 | hold | HOLD | dead leaf sites with no route | the census keeps it at 0 | item 229 §5 |
| `trueOnly` | 0 | 0 | 0 | hold | HOLD | recursor motives exporting only `True` | the census keeps it at 0 | items 231 / 232 |

### `ColumnWalkPrice` — open=2 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `withSuffixLemma` | 88 | 96 (= `productions`) | 8 | grow-only | OPEN | suffix lemmas over the typed productions | as `SurfaceSpanCensus.covered` | item 235 |
| `missing` | 8 | 0 | 8 | shrink-only | OPEN | suffix lemmas | as `SurfaceSpanCensus.covered` | item 235 |
| `documentLayerMissing` | 1 | 1 | 0 | hold | HOLD | `[211]`'s missing document-layer suffix lemma (the statement is false) | β.5 (see `SuffixGapAudit.refuted`) | items 235 / 236 |

### `scripts-ledger` — open=0 done=1 hold=0

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `rows` | 0 | 0 | 0 | shrink-only | DONE | Rule 9: scripts are Lean | port each `todo` row to a `lean_exe` (plan `Blueprint/09-scripts-in-lean.md`); an `exception` row needs the owner's reason | Rule 9 (PR #193); `lake run check-scripts-lean` (shrink-only pin `# open: N`) |

### `GateVocabulary` — open=0 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `unresolved` | 0 | 0 | 0 | hold | HOLD | every gate name the prose cites resolves | `lake run check-gate-vocab` keeps it at 0 | items 265 / 266 |

### `OpenerFallbackReach` — open=1 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `fallback` | 0 | 0 | 0 | hold | HOLD | the openers' catch-all route arm is unreachable | the guard keeps it at 0 | item 375 |
| `open` | 18 | 0 | 18 | shrink-only | OPEN | the five openers' `_ ∨ True` optional contexts (`h_res_land`, `h_sfx_land`, `h_nodoc_land`, `h_mk_land`, `h_pr_land`, …) | Row 19's step (3) explicit-only narrowing (item 494's 13 sites) and R12's (2b) fixpoint; each context made plain at its producers | items 375 / 494 |

### `ColumnAdvanceCensus` — open=0 done=0 hold=3

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `violations` | 1 | 1 | 0 | hold | HOLD | the column law is false and ONE arm refutes it (`SLDocumentPrefix.bom`) | a second violation is a finding, not a count to chase | item 234 |
| `blind` | 0 | 0 | 0 | hold | HOLD | arms the column census could not relate (a census reporting no violation must see its population) | the census keeps it at 0 | item 234 |
| `value` | 0 | 0 | 0 | hold | HOLD | applications of `GConsumeAll` outside its generated machinery (the arm that could break the column law) | the guard keeps it at 0 | item 234 §4 |

### `ConclusionObligationCensus` — open=1 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `res` | 51 | 0 | 51 | shrink-only | OPEN | `Or.inr trivial` written in the ledger lemmas' conclusions | narrow each conclusion to its residue (item 228: price the relay damage first; `res` 123 → 58 was the lane's own direction) | items 227 / 228 |
| `byTrivial` | 0 | 0 | 0 | hold | HOLD | a narrowed residue that `trivial` still proves | the probe keeps it at 0 | item 228 §2b |

### `ProducerDerivation` — open=0 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `free` | 0 | 0 | 0 | hold | HOLD | correspondence hypotheses that are free | the census keeps it at 0 | item 241 |

### `StreamCompositions` — open=0 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `viaSites` | 0 | 0 | 0 | hold | HOLD | build points reached only through a `VIA` | the census keeps it at 0 | item 249 |

### `CarrierArmPrice` — open=0 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `drop` | false | `false` | 0 | hold | HOLD | non-circularity: the closing lemma routes through no escape | the check keeps it `false` | items 242–245 |

### `ParkGapCensus` — open=0 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `drop` | false | `false` | 0 | hold | HOLD | non-circularity of the connected-drop closure | the check keeps it `false` | item 243 |

### `ParkGapWidth` — open=0 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `drop` | false | `false` | 0 | hold | HOLD | non-circularity of the width proofs | the check keeps it `false` | item 244 |

### `ParkGapProduction` — open=0 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `drop` | false | `false` | 0 | hold | HOLD | non-circularity of the literal's production | the check keeps it `false` | item 245 |

### `DispatchPrice` — open=0 done=0 hold=1

| field | now | goal | left | move | status | serves | what moves it | basis |
|---|---:|---:|---:|---|---|---|---|---|
| `drop` | false | `false` | 0 | hold | HOLD | the weak repair's statement routes through no escape | the check keeps it `false` | item 242 |

## Readings without a target

Pinned counts the roster gives no direction: snapshots (term sizes, thread lengths, the rows of a walk) and prices. A count here that the campaign drives somewhere belongs on the roster (`Scripts/Census/Dashboard.lean`).

- `ArmSpendCensus`
  - `expectedTally`: edges=102 skipped=41 FIELD=7 PAY=14 RELAY=30 VIA=29
- `BlockDeferralClasses`
  - `expectedInlineFeeders`: errors=6 decls=2
  - `expectedInlineArms`: decls=3
  - `expectedInlineCensus`: rows=432 accepted=371 popped=37 onto-map=37 onto-seq=0 off-level=0
  - `expectedPackFlip`: sites=95 decls=19 rounds=2 leaf=69 stubs=8
  - `expectedPackResidue`: sites=74 decls=15 rounds=2 relayTrue=0 leaf=58 stubs=1 promised=6
- `CapstonePathAudit`
  - `expectedSummary`: positions=253 off-unreached=0 on-drop-nested=0 on-via-nested=0 on-relay-nested=0 off-honest-nested=15 nested-unresolved=67 True=0 PackAlt=7 PackAltG=0 streamAccum-reached=1151/1261 unrooted-arms=94 arms=237 relays=138 drop-set=7/8
- `CarrierArmPrice`
  - `expectedLine`: prods=175 ctors=336 same=27 direct=308 anchoredOnly=25 broken=3 surfArms=184 surfDirect=183 readers=3 libReaders=2 guardReaders=1 mentions=44 producers=21 absorbReaders=5 absorbPlainReaders=0
- `CloseLandingWidth`
  - `expectedLine`: closeSites=5 closePairs=6 closePairsD=8 viaClose=3 params=5 spends=23 spendsC=5 spendsE=0 spendsN=18 handoffs=7 carries=1 untyped=1 edges=3 paramsWalked=7 widthInd=4 widthWs=1 widthNone=0 idxDirect=3 idxPacked=1 idxNone=1 cmp=0 cmpSame=0 both=3 bothCmp=0 handInd=6 handDirect=7 handCmp=6 sitesBoth=1 sitesWidth=2 sitesNeither=2 sitesBothAll=0 empties=31 emptyLemmas=9 emptyInd=15 emptyCmp=7 emptySame=1 emptyClose=2 sites=20 pairs=20 pairs21=20 pairs18=18 nonANoDrop=8 reach=37
- `CloseSplitFrames`
  - `expectedLine`: asked=5 both=3 lemmas=1 walked=4 feedFunnel=1 feedExplicit=1 feedDeferred=1 feedTuple=0 entry=3 entrySBI=3 kslot=0 kslotUp=0 closeF=3 closeFV=3 seqF=0 top=3 floor=0 cover=3 cover2=3 floorB=3 aboveKN=0 aboveKMem=0 aboveKNv=0 aboveKEx=0 hands=1 besideKN=1 besideKMem=1 besideKNv=0 puntKN=1 puntKMem=0 besideNone=0 decisions=155 decOnK=20 decKN=14 decKMem=6 decKNv=0 apps=60 funnelArgs=1 doorDropped=4/1 closeSites=5 params=5
- `CloseStackCover`
  - `expectedLine`: positions=24 ctorFields=7 lemParams=23 lemmas=19 walked=26 doors=9 rows=125 ctorRows=49 lemRows=47 localRows=4 fnRows=19 fnpRows=4 valRows=2 coverTypes=5 mentions=0 pbc=6 pbcRelay=6 pbcPaid=0 pbcPunt=0 pbcCoverPunt=0 pb=7 pbRelay=3 pbPaid=4 pbPunt=0 pbCoverPunt=0 pmv=6 pmvRelay=4 pmvPaid=1 pmvPunt=0 pmvCoverPunt=1 valF=11 valFRelay=2 valFPaid=0 valFPunt=9 contentPaid=6 contentPunt=13 contentCoverPunt=4 contentLemma=0 contentOpen=2 contentPos=17 entryPaid=6 entryPunt=13 entryCoverPunt=4 entryLemma=0 entryOpen=2 entryPos=17 eight=6 eightPB=3 eightPBC=3 eightIndents=0 eightTop=3 eightFloor=0 eightMinCI=0 eightNic=6 eightPrep=6 eightCover=6 doorUses=49 doorKept=9 doorForgotten=17 doorDropped=23 doorsOther=5 nodes=126551
- `ColumnAdvanceCensus`
  - `expectedSplit`: types=81 arms=184 advance=27 pred=11 reset=3 carried=142
  - `expectedCoverage`: lits=87 pairs=48 skippedTypes=1
- `ColumnWalkPrice`
  - `expectedCycles`: types=81 sccs=64 cyclic=8 acyclic=56 cyclicTypes=25 cyclicArms=91 largest=10
  - `expectedPrice`: arms=184 links=367 oneWalk=367 twoWalks=917 defProds=9 defCitations=42
  - `expectedCyclePrice`: arms=51 links=155 oneWalk=155 twoWalks=414
  - `expectedSupply`: productions=96
- `ConclusionObligationCensus`
  - `expectedResidueProbe`: residues=4 byChain=0 optShaped=0
  - `expectedLedgerTally`: rows=14
  - `expectedFamily`: types=20 ctors=79 suffixLemmas=20
- `ConclusionRouteCensus`
  - `expectedTally`: positions=18 skipped=0 SPLIT=15 UNREACHABLE=2 VIA=1
  - `expectedPipeSplit`: pipes=0/0 producers=26/9 landed=100 landed-producers=10 total=126
- `DeadDeclarationCensus`
  - `expectedDeadCensus`: population=14050 thm=10170 def=2513 unreached=5949 A-campaign=1125 C-api=1244 D-test-only=272 cluster-roots=1459
- `DispatchPrice`
  - `expectedAlphabet`: prodTyped=175 prodSurf=96 prodSpec=58
  - `expectedSteps`: stepHolders=2110 dispHolders=430 dispTwoCorr=42 fns=75 fnsIx=26
- `DropDependents`
  - `expectedClosure`: value=287
  - `expectedWide`: closure=883 imported=879 excluded=37 readable=37 unreadable=0 excludedDecls=603 excludedDropRefs=0
  - `expectedWideCensus`: D=4 S=0 R=0 capstonesInT=2 rawElim=11
  - `expectedCensus`: R=0 rawElim=11
- `DropFalsity`
  - `expectedTally`: bound=14 empty=10 free=5 negation=3 total=32
- `ExitHandoff`
  - `expectedLine`: producers=21 readers=3 builders=18 share=18 outsideShare=3 shareInT=3 shareOutsideT=15 buildersOutsideT=14 nilOutsideT=26 walked=25 slots=62 nil=44 carrier=15 forward=3 other=0 loose=4 atInput=38 atParam=1 atBound=5 atExpr=0 nilStreamParam=33 nilStreamBound=11 handedNone=0 flowOpen=5 handedPromise=35 handedDemand=1 handedBound=3 posFree=53 through=15
- `FreeSurfaceCensus`
  - `expectedClosure`: modulesSeen=281
  - `expectedCensus`: theorems=110 headYaml=5 headStream=35 nestedConcl=62 hypOnly=8 yamlInHypothesis=0
- `GateVocabulary`
  - `expectedGateVocab`: names=115 mentions=519 families=14 refuted=7 wrapped=4 self=2
- `GhostIndexCensus`
  - `expectedSummary`: carriers=64
- `HypothesisReaderCensus`
  - `expectedModuleTally`: constants=1745 decls=1389 eta=611 FIELD=175 READ=1421 RELAY=2909 RETURN=56 UNUSED=24
  - `expectedOptTally`: total=158 ETA=31 READ=88 RELAY=39
  - `expectedPuntFields`: tab=4 implicitValue=3 markerLine=2 noKeyContext=0
- `NarrowingWorthCensus`
  - `expectedFaceTally`: faces=62 heads=18
  - `expectedFidelity`: binders=158 surf=133 state=25
  - `expectedWorthTally`: pairs=37 splits=109 sup=100 chainPairs=0 innerPairs=13 innerSplits=56
  - `expectedBranchReach`: branchPairs=37 stateReachable=1 splits=109 stateSplits=3
  - `expectedHiddenTally`: hiddenDefs=1 syntactic=152 population=154
  - `expectedNoopTally`: theorems=6421 byWhnf=14 elabOnly=0 whnfOnly=0
- `OpenEntryRoute`
  - `expectedLine`: aPairs=10 aSites=13 t1Pairs=2 t1Sites=4 t2Pairs=7 t2Sites=8 nPairs=1 nSites=1 multi=0 inline=0 covered1=2 covered2=9 stackedPairs=0 stackedNoDrop=0 nonA=10 nonANoDrop=8 pairs21=20 pairs18=18 sites=20 pairs=20 exhibits=5 closedFirst=1 handedNode=4 avail=13 behindLemmas=5 behindOpeners=0 aheadOpeners=3 funnelApps=4 paid=2 punted=2 other=0 chainApps=4 entryApps=6 qApps=1 cApps=1 reach=37
- `OpenerFallbackReach`
  - `expectedSummary`: openers=5 pays=18
- `OrTrueAudit`
  - `expectedSummary`: modules=2 paid=26 relayed=117 spent=102 writers=37
- `PaidLeafDelta`
  - `expectedLine`: rows=125 payments=1 literal=0 relay=1 scenarios=2 baseContent=17/6/13/4/2 allContent=19/6/12/6/2 baseEntry=17/6/13/4/2 allEntry=19/6/12/6/2 turnedPaidContent=0 turnedPaidEntry=0 originsBaseContent=6 originsAllContent=6 originsBaseEntry=6 originsAllEntry=6 floorLits=101 own=12 lit=6 var=83 ownLemmas=2 scanned=36 monoIndex=11 monoIndexLemmas=7 floorCons=4 floorConsLemmas=2 floorPopTo=1 floorPopToLemmas=1 leOfMem=0 coveredPopTo=1 coveredPopToLemmas=1 raiseFloor=0 dedupHead=2 dedupHeadLemmas=2 coveredCons=14 rootMonoCaller=1 rootMonoSite=1 rootNtop=1 nodes=126551 floorNodes=34961
- `ParkBill`
  - `expectedClosure`: value=288
  - `expectedBill`: T=32 shared=25 extra=14
  - `expectedFixpoint`: rounds=23 clean=1 restated=0 deleted=3 pins=37 gone=1 free=4
  - `expectedArms`: control=7 dead=6
  - `expectedGateHolders`: dn/mid=23 dn/eof=5 fv/mid=17 fv/eof=4
- `ParkGapCensus`
  - `expectedPop`: D=4 T=33 pop=9 sites=12
  - `expectedTally`: syn=0 deq=0 eqHyp=0 forced=0 corrBlock=0 corrScan=3 atPark=3 parkSpan=4 noSpan=8 otherSpan=0
- `ParkGapProduction`
  - `expectedLine`: pop=9 sites=9 spend=3 nospend=6 len1=3 depth=3 prods=175 ctors=336 endsLit=48 minus=1 question=3 colon=26 chainEnds=0 blockArms=1 seqArms=10 mapArms=10 streamArms=4 streamHonest=3
- `ParkGapWidth`
  - `expectedPop`: pop=9 sites=9
  - `expectedWidth`: w0=0 w1=3 w2=2 unreached=4 corrBlock=0 corrScan=9
- `PremiseNecessityCensus`
  - `expectedModuleTallyP`: constants=1745 decls=1389 eta=611 FIELD=201 READ=1484 RELAY=2701 RETURN=175 UNUSED=24
  - `expectedOptTallyP`: total=158 ETA=31 FIELD=4 READ=88 RELAY=33 RETURN=2
  - `expectedDeadTally`: RELAY=5 UNUSED=25
  - `expectedOptPopulation`: total=158 optTy=152 ctorFields=31
- `ProducerDerivation`
  - `expectedCensus`: corrHyp=635 streamConcl=91 both=44 pairConcl=1 held=3 pairAny=8
  - `expectedHeldOnThreads`: onProdThread=0 onThread=0
  - `expectedProdThread`: prodThread=23 rings=9 withCorr=18 covered=0
  - `expectedProdInT`: prodInT=15 prodOutsideT=8 union=27 unionOutsideT=8
- `PuntCoverInputs`
  - `expectedLine`: sites=3 pb=0 pmv=0 props=3 idx0=2 mono=1 monoOpt=0 base=1 baseOpt=0 prep=1 dispB=0 dispC=3 hc=2 chr=2 dash=0 corr=3 noflow=3 save=1 fl=0 top=0 larm=0 floor=1 nic=3 armed=0 col0=1 ids=0 coverSites=1 coverBinders=4 coverFnSites=3 full=0 fullB=0 missMono=2 missBase=2 missPrep=2 missFloorSrc=3 own=0 empty=0 relay=1 relayEntries=4 bounds=0 below=0 belowSyn=0 belowArm=0 at=0 atSyn=0 atArm=0 undecided=0 bOwn=0 bOld=0 landedBelow=0 inlineBelow=0 payable=0 lack=2 lackCallers=16 lackSupplied=0 lackSuppliedB=2 lackLow=2 lackPayable=0 vacuous=2 bottomBelow=0 paidRows=16 bottomPaidBelow=5 bottomPaidRelay=9 named=8 rows=125 nodes=126551
- `RelaySupplyCensus`
  - `expectedTally`: edges=636 skipped=41 FIELD=60 LOCAL=26 PAY=51 RELAY=64 SPLIT=175 VIA=26
  - `expectedPipeLanding`: piped=100 producers=10 VIA=8 SPLIT=20 FIELD=37 LOCAL=5 PAY=1 RELAY=18
  - `expectedSplitLanding`: survived=175 collapsed=10 leaves=422 elsewhere=11 PAY=197 VIA=11
  - `expectedSplitBranch`: splits=175 leaves=422 relayRooted=161 siteDecided=14 optionalRoot=109 plainRoot=52 agree=116/116 PAY-free=197 L4YAML.Proofs.StreamAccum.deeperLandingResume-=2 L4YAML.Proofs.StreamAccum.flowKeyRoute_of_root-=1 absurd-=8
  - `expectedDeclineReach`: pairs=37 orphan=4 direct=7 closureDecline=33 maxDepth=2 liveSplits=103 deadSplits=0 accounted=636/636 nodes=157 fieldEdges=60 fieldResolved=60 withCycle=10 declineWriters=19 parkHop=22
- `RepairChoice`
  - `expectedThread`: thread=19 prodThread=23 shared=15 capstones=2 rings=8
  - `expectedDiscriminator`: withPark=3 covered=0 total=19
  - `expectedInT`: threadInT=19 outsideT=0
  - `expectedEmptyClass`: empty=10 onThread=6
  - `expectedParkReadings`: users=12 rawRefs=11 fullApps=11
- `RouteShapes`
  - `expectedLine`: closures=58 packed=14 optional=42 guarded=17 facts=3 others=4 byHead=6 byFirst=9 bySpine=42 flowRoutes=7 flowSpinesNew=6 slots=62 nil=44 parkedCtor=35 closureSlots=280 stream=7 carry=192 fwd=0 closed=12 packSlots=104 spinesFromStream=5 spinesCarried=35 spinesTouched=40 firstsFromStream=4 headsFromStream=3 streamSites=2 closings=11 closedDistinct=3 closedIn=1 absorbed=4 obtained=2 flowSites=7 flowSlots=49 routeArgs=185 routeStream=16 routeCarry=68 routeFwd=58 routeClosed=43 routeToWalked=117 routeStreamToWalked=11 viaObtained=0 viaSites=0 builders=12 builds=170 buildSlots=1185 buildStreamSlots=16 buildSpines=10 routePairs=7 routeSpines=5 k=14 kHeads=6 streamBuilders=8
- `ScannerFlowOpenUnderRun`
  - `expectedCarrierPrice`: core=7 slot=7 prop=8 consumer=1 gate=1
  - `expectedWirePrice`: gate=49 anchor=2 route=3 eof=1
  - `expectedArmTable`: cells=24
  - `expectedCoordPrice`: lib=1
  - `expectedTransportPrice`: optok=3 frames=8 ride=0/3
  - `expectedRidePrice`: ride=1/1 add=6/4 swap=4/4 anchor=4/4 transport=9/7
  - `expectedClosePrice`: gate=1/1 close=4/1 closable=20/5 apps=2
- `StreamCompositions`
  - `expectedLine`: sites=20 genuine=20 pairs=20 segments=40 genuineSegs=39 facts=1 stacked=0 comps=14 byCtor=11 byFull=39 shapes=14 shapeComps=20 shapeCompsNoDrop=18 obtainedSites=8 approxSites=0 prev=16 new=5 missing=1 prevStyle=16 prevStyleOff=0 newVsStyle=5 styleOnly=1 segHops=11 segAbsorb=3 single=0 dropClose=1 directive=1 hops=13 hopMax=4 approx=37 dead=8 opaque=0 unmarked=156 reach=37
- `SuffixGapAudit`
  - `expectedChain`: types=81 arms=184 paramOnly=7
  - `expectedSplit`: missing=8 aliases=7
- `SurfaceSpanCensus`
  - `expectedClosure`: types=79 ind=66 def=13 ctors=160 block=20/79 leaf=59/81
  - `expectedCoverage`: closure=79
  - `expectedLeafSplit`: exports=8 noop=0 carried=108 payable=62 relay=46
  - `expectedArmPrice`: types=16 ctors=26 prod=9/16 comb=4/6 forecast=7/12
  - `expectedMotiveExport`: motives=20 flow=8 residue=8 none=0
  - `expectedDemand`: exports=8/0 wrappers=3/2 payments=6/0 leaves=6/0
  - `expectedPaymentShape`: payments=6 resolveRight=6 maxPayment=111 export=78011
  - `expectedRefuters`: mentions=25 lift=11 span=14 corrFields=5 posFields=2
  - `expectedRefutationSupply`: produces=2 assumes=6 overDerivation=0
- `ValueLineOrigins`
  - `expectedLine`: positions=52 packaged=7 rows=198 ctorRows=104 paramRows=94 packagedRows=29 stamp=37 built=157 origins=70 originRows=35 route=12 frames=29 tail=15 other=0 concl=8 invariant=6 heldOrigins=14 allHeld=2 someHeld=125 noneHeld=13 unbornRows=0 relayedPunt=0 relayedStamp=10 relayedAbsurd=7 relayedFact=0 deadRows=0 unbornPos=0 rounds=4 follows=416 lets=770 lapps=1231 alts=5678 nodes=14655 liteNodes=694100
- `ValueLinePacks`
  - `expectedLine`: packs=12 framesOn=7 params=33 paramLemmas=20 apps=51 rows=169 ctorRows=80 paramRows=89 stamp=24 empty=2 relay=37 step=10 via=3 chain=55 route=2 frames=3 tail=2 other=7 alt=8 held=7 levelVar=57 none=16 spendTail=10 lemmas=21 touched=153 nodes=14620
- `scripts-ledger`
  - `open`: pin=0
