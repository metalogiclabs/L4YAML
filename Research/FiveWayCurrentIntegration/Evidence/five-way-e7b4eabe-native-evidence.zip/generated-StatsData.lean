/-
  Doc.L4YAML.StatsData — embedded `stats.json` payload for `:::statsTable`.

  GENERATED FILE — regenerate with `lake exe collect-stats --emit-lean`
  (repo root). The COMMITTED version is a deliberate placeholder (`none`):
  the at-a-glance table renders every cell as "?" so a fresh clone builds
  the docs hermetically without running collect-stats first.

  CI regenerates this file (workspace-only, never committed back) after
  the test suites and right before the doc build, so the published site
  always embeds the current run's stats. Because `StatsTable` IMPORTS
  this module instead of reading `docs/reports/stats.json` at elaboration
  time, the dependency is visible to Lake: a content change re-elaborates
  exactly the importing `Doc.*` modules — no IO at elaboration, no hidden
  staleness if `.lake` caching is ever enabled.
-/

namespace Doc.L4YAML.StatsData

/-- Compact `stats.json` payload embedded at generation time;
    `none` in the committed placeholder (every table cell renders "?"). -/
def statsJson? : Option String := some "{\"build_jobs\":null,\"env\":{\"axioms\":0,\"custom_axiom_names\":[],\"raw_nonstandard_axioms\":727,\"replay_validated_axioms\":727,\"theorems\":17155,\"theorems_with_custom_axiom\":0,\"theorems_with_direct_sorry\":0,\"theorems_with_transitive_sorry\":0},\"generated_at_ms\":1863916,\"schema_version\":3,\"spec_examples\":{\"passed\":132,\"total\":132},\"static\":{\"library\":{\"axioms\":1,\"guards\":106,\"lean_files\":286,\"lemmas\":9480,\"lines\":302515,\"partial_defs\":9,\"theorems\":55,\"theorems_plus_lemmas\":9535},\"proofs\":{\"axioms\":0,\"guards\":103,\"lean_files\":214,\"lemmas\":9236,\"lines\":273169,\"partial_defs\":0,\"theorems\":49,\"theorems_plus_lemmas\":9285},\"tests\":{\"axioms\":3,\"guards\":8477,\"lean_files\":711,\"lemmas\":298,\"lines\":181613,\"partial_defs\":163,\"theorems\":2623,\"theorems_plus_lemmas\":2921}},\"test_suites\":{\"suite_count\":15,\"suites\":[{\"name\":\"unit-tests\",\"passed\":10,\"total\":10},{\"name\":\"explicit-key-tests\",\"passed\":149,\"total\":149},{\"name\":\"flow-tests\",\"passed\":88,\"total\":88},{\"name\":\"validation-tests\",\"passed\":84,\"total\":84},{\"name\":\"dump-roundtrip\",\"passed\":252,\"total\":252},{\"name\":\"raw-parse-tests\",\"passed\":29,\"total\":29},{\"name\":\"scanner-tests\",\"passed\":55,\"total\":55},{\"name\":\"scanner-spec-examples\",\"passed\":132,\"total\":132},{\"name\":\"adversarial-tests\",\"passed\":159,\"total\":159},{\"name\":\"mutation-tests\",\"passed\":45,\"total\":45},{\"name\":\"property-tests\",\"passed\":124,\"total\":124},{\"name\":\"production-coverage\",\"passed\":847,\"total\":847},{\"name\":\"limit-tests\",\"passed\":67,\"total\":67},{\"name\":\"schema-dump\",\"passed\":111,\"total\":111},{\"name\":\"demo\",\"passed\":7,\"total\":7}],\"total_passed\":2159,\"total_tests\":2159},\"yaml_test_suite\":{\"applicable\":358,\"correct\":358,\"correctRate\":100,\"expectedFail\":95,\"failed\":0,\"passed\":263,\"skipped\":48,\"timeout\":0,\"total\":406,\"unexpectedPass\":0}}"

end Doc.L4YAML.StatsData
