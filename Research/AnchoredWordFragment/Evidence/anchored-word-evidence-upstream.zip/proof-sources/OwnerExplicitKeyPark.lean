module
public import L4YAML.Proofs.Serialization.TraceOf.StreamBridge
public section
namespace L4YAML.Tests.Guards.OwnerExplicitKeyPark
open L4YAML L4YAML.Scanner L4YAML.Surface L4YAML.CharPredicates
open L4YAML.Proofs.Serialization.SerializationWellFormed
open L4YAML.Proofs.Serialization.TraceOf
open L4YAML.Proofs.Serialization.TraceOf.DocBridge
open L4YAML.Proofs.Serialization.TraceOf.StreamBridge
open L4YAML.Proofs.Serialization.TraceOf.ContentBridge
open L4YAML.Proofs.Serialization.TraceOf.FlowWalk
open L4YAML.Proofs.CouplingBridge L4YAML.Proofs.StructureProduction
open L4YAML.Proofs.ScalarProduction L4YAML.Proofs.NodeProduction L4YAML.Proofs.Acceptance
open L4YAML.Proofs.PreprocessIndentStable L4YAML.Proofs.PreprocessProduction
open L4YAML.Proofs.ScannerWhitespace L4YAML.Proofs.ScannerCoupling
open L4YAML.Proofs.TabIndentBridge
open L4YAML.Proofs.StreamAccum (ContentArm NextIsSep SlotGateAt white_prepend_SSLComments)
set_option maxHeartbeats 4000000

-- Port only the already qualified comment-gate retention to the exact owner's
-- leaf proof. No change to the owner grammar or existing consumers.
lemma content_leaf_at_retained (n : Nat) {s_ad s' : ScannerState} {c : Char} {sp_prep : SurfPos}
    (hcorr : ScannerSurfCorr s_ad sp_prep) (hpeek : s_ad.peek? = some c)
    (h_flow : s_ad.inFlow = false)
    (h_not_doc : s_ad.col = 0 → atDocumentBoundary s_ad = false)
    (h_amp : c ≠ '&') (h_star : c ≠ '*') (h_bang : c ≠ '!') (h_pipe : c ≠ '|') (h_gt : c ≠ '>')
    (h_dispatch : scanNextToken_dispatchContent s_ad c = .ok s')
    (hn : n ≤ L4YAML.Proofs.PreprocessIndentStable.minContentIndentOf s_ad) :
    ∃ sp_gram sp', TFlowContent n .flowOut sp_prep sp_gram [] ∧ GStar SSWhite sp_gram sp' ∧
      (sp_gram = sp' → s'.col ≠ 0 →
        ¬ (CommentOk s' ∧ s'.peek? = some '#')) ∧ ScannerSurfCorr s' sp' := by
  obtain ⟨rest, hsp_prep⟩ := peek_some_sp hcorr hpeek
  have hglue := L4YAML.Proofs.StreamAccum.content_not_glue h_dispatch
  simp only [isFlowIndicatorBool, Bool.or_eq_false_iff, decide_eq_false_iff_not,
    List.mem_cons, List.mem_nil_iff, or_false, not_or] at hglue
  have hlb : c ≠ '[' := hglue.2.2.1
  have hlc : c ≠ '{' := hglue.2.2.2.2.1
  have hn_max : (n : Int) ≤ max 0 (s_ad.currentIndent + 1) := by
    unfold L4YAML.Proofs.PreprocessIndentStable.minContentIndentOf at hn
    omega
  by_cases hdq : c = '"'
  · subst hdq
    obtain ⟨sp', hg, hpb, hcorr'⟩ :=
      L4YAML.Proofs.StreamAccum.dispatchContent_doubleQuoted_prod_at n s_ad sp_prep hcorr hpeek
        h_dispatch hn_max
    exact ⟨sp', sp', .doubleQ _ _ _ _
      (L4YAML.Proofs.ScalarFoldAt.SCDoubleQuoted_multiCtx .flowOut (Or.inl rfl) hg), GStar.nil _, fun _ => L4YAML.Proofs.StreamAccum.park_gate_of_peekBack hpb (by decide), hcorr'⟩
  · by_cases hsq : c = '\''
    · subst hsq
      obtain ⟨sp', hg, hpb, hcorr'⟩ :=
        L4YAML.Proofs.StreamAccum.dispatchContent_singleQuoted_prod_at n s_ad sp_prep hcorr hpeek
          h_dispatch hn_max
      exact ⟨sp', sp', .singleQ _ _ _ _
        (L4YAML.Proofs.ScalarFoldAt.SCSingleQuoted_multiCtx .flowOut (Or.inl rfl) hg), GStar.nil _, fun _ => L4YAML.Proofs.StreamAccum.park_gate_of_peekBack hpb (by decide), hcorr'⟩
    · obtain ⟨sp_g, sp', hcont, hws, hhash, hcorr'⟩ :=
        L4YAML.Proofs.StreamAccum.dispatchContent_plainScalar_content_prod_at n s_ad sp_prep hcorr hpeek
          h_amp h_star h_bang h_pipe h_gt hdq hsq h_not_doc h_dispatch h_flow hn
      subst hsp_prep
      exact ⟨sp_g, sp', TFlowContent.of_scalar hcont hlb hlc, hws, fun he _ hh => hhash he hh.2, hcorr'⟩

/-- The explicit-key park is a deferred map entry, not a completed node.
    Store its actual scanner correspondence, native indicator follower,
    and the map route the value will consume. -/
structure QuestionPark (start q after : SurfPos) (n : Nat)
    (sc : ScannerState) (ec eo : List Event) : Prop where
  question : GLit '?' q after
  corr : ScannerSurfCorr sc after
  floor : IndentFloor sc (n + 1)
  col : n + 1 ≤ after.col
  next : NextIsSep sc
  noflow : sc.inFlow = false
  route : ∀ sp ev, TBlockMapEntry n q sp ev → TLYamlStream start sp (ec ++ eo ++ ev)

/-- The key's grammar, actual scanner landing, whitespace and comment gate
    survive until the matching colon. Event index permits future non-silent arms. -/
inductive KeyReady (start q after scan : SurfPos) (n : Nat)
    (sc : ScannerState) (ec eo ek : List Event) : Prop where
  | ready (gram : SurfPos)
      (hquestion : GLit '?' q after)
      (hcorr : ScannerSurfCorr sc scan)
      (hrun : GStar SSWhite gram scan)
      (hgate : gram = scan → sc.col ≠ 0 → ¬ (CommentOk sc ∧ sc.peek? = some '#'))
      (hkey : ∀ sp_key, SSLComments gram sp_key → TBlockIndented n .blockOut after sp_key ek)
      (hroute : ∀ sp ev, TBlockMapEntry n q sp ev → TLYamlStream start sp (ec ++ eo ++ ev)) :
      KeyReady start q after scan n sc ec eo ek

lemma question_park_from_scan
    {start q : SurfPos} {s sc : ScannerState} {ec eo : List Event}
    (hcorr : ScannerSurfCorr s q) (hpeek : s.peek? = some '?')
    (hdispatch : scanNextToken_dispatchBlockIndicators s '?' = .ok (some sc))
    (hflow : s.inFlow = false)
    (hnic : s.needIndentCheck = false)
    (route : ∀ sp ev, TBlockMapEntry s.col q sp ev →
      TLYamlStream start sp (ec ++ eo ++ ev)) :
    ∃ after, QuestionPark start q after s.col sc ec eo := by
  have hok := L4YAML.Proofs.StreamAccum.dispatchBlock_question_scanKey hdispatch
  have hnext := L4YAML.Proofs.StreamAccum.dispatchBlock_question_next hflow hpeek hdispatch
  obtain ⟨after, hq, hc⟩ := scanKey_prod s q hcorr hpeek sc hok
  have hf : IndentFloor sc (s.col + 1) :=
    IndentFloor.succ_of_int_le ((scanKey_needIndentCheck hflow hok).trans hnic)
      (scanKey_col_le_currentIndent hflow hok)
  have hcol : s.col + 1 ≤ after.col := by
    have hqc := hcorr.col_eq
    cases hq
    simp_all
  have hnf : sc.inFlow = false := by
    unfold ScannerState.inFlow at hflow ⊢
    rw [L4YAML.Proofs.ScannerCorrectness.scanKey_preserves_flowLevel s sc hok]
    exact hflow
  exact ⟨after, ⟨hq, hc, hf, hcol, hnext, hnf, route⟩⟩

/-- Scalar content step off the real explicit-key park. Unlike content_step_at,
    this must not close the enclosing stream before the colon. Dedent is
    retained as a separate outcome. The scanner/event coupling is advanced. -/
lemma explicit_scalar_content_step
    {start q after sp_block sp_prep sp_a : SurfPos}
    {n : Nat} {sc s_prep s_ad s' : ScannerState} {c : Char} {ec eo : List Event}
    (hS : TSLYamlStream start s_ad sp_block ec eo [])
    (park : QuestionPark start q after n sc ec eo)
    (h_ad : s_ad = if s_prep.allowDirectives then
      { s_prep with allowDirectives := false, documentEverStarted := true } else s_prep)
    (hcorr_prep : ScannerSurfCorr s_prep sp_prep)
    (hcorr' : ScannerSurfCorr s' sp_a)
    (h_preprocess : scanNextToken_preprocess sc = .ok (some (s_prep, c)))
    (arm : ContentArm s_ad s' c sp_prep sp_a)
    (h_depth : s_ad.flowLevel = 0)
    (h_dispatch : scanNextToken_dispatchContent s_ad c = .ok s')
    (h_not_doc : s_ad.col = 0 → atDocumentBoundary s_ad = false)
    (h_amp : c ≠ '&') (h_star : c ≠ '*') (h_bang : c ≠ '!')
    (h_pipe : c ≠ '|') (h_gt : c ≠ '>')
    (h_src : SlotGateAt s_prep) :
    (TSLYamlStream start s' sp_block ec eo [] ∧
      KeyReady start q after sp_a n s' ec eo []) ∨
      L4YAML.Proofs.FlowIndexLift.DedentLanding (n + 1) after sp_prep := by
  have h_col0 : 0 < after.col := by have h := park.col; omega
  have hflow : s_ad.inFlow = false := by unfold ScannerState.inFlow; rw [h_depth]; rfl
  have hcorr_ad : ScannerSurfCorr s_ad sp_prep := by
    rw [h_ad]
    exact L4YAML.Proofs.StreamAccum.corr_of_allowDirectives_update hcorr_prep
  have hpeek : s_ad.peek? = some c := by
    rw [h_ad]
    have := L4YAML.Proofs.StreamAccum.preprocess_some_peek h_preprocess
    split <;> exact this
  rcases TPendingNode.content_sep_of_preprocess h_ad park.floor park.col h_col0 park.next park.corr
      hcorr_prep hcorr' h_preprocess h_not_doc hflow h_dispatch h_src with
    ⟨h_sep, h_fl⟩ | h_ded
  · obtain ⟨sp_gram, sp_res, hT, hws, hgate, hcorr_res⟩ :=
      content_leaf_at_retained (n + 1) hcorr_ad hpeek hflow h_not_doc
        h_amp h_star h_bang h_pipe h_gt h_dispatch h_fl
    obtain rfl : sp_res = sp_a := ScannerSurfCorr_unique hcorr_res hcorr'
    obtain ⟨ev_n, hpt, hdisj⟩ := accum_step_content_trace_out arm hcorr_ad hpeek h_depth h_dispatch
    have hev : ev_n = [] := by
      rcases hdisj with ⟨hev, -⟩ | ⟨hev, -⟩ | ⟨hev, -⟩ | ⟨hc, -⟩ | ⟨hc, -⟩ | ⟨hc, -⟩
      · exact hev
      · exact hev
      · exact hev
      · exact absurd hc h_amp
      · exact absurd hc h_bang
      · exact absurd hc h_star
    subst ev_n
    refine Or.inl ⟨⟨hS.stream, by rw [hpt.goOut_at [], hS.events]; simp⟩,
      .ready sp_gram park.question hcorr' hws hgate ?_ park.route⟩
    intro sp_key hssl
    exact .node _ .blockOut _ _ []
      (.flowInBlock _ .blockOut _ _ _ _ [] h_sep (.content _ _ _ _ _ hT) hssl)
  · exact Or.inr h_ded

/-- Matched colon: consume a retained key and actual preprocessing/scanValue,
    then return the owner's existing pendingMapValue and ContentPark constructors.
    This is generic in the key's event suffix; scalar construction above is silent.
    Nonmatching colons and closure without a colon are deliberately not admitted. -/
lemma retained_key_to_owner_value_park
    {start q after scan sp_colon sp_block : SurfPos} {n : Nat}
    {s sc_colon sc_after : ScannerState} {vc : Char} {ec eo ek : List Event}
    (park : KeyReady start q after scan n s ec eo ek)
    (h_deeper : n < scan.col) (h_colon_col : sp_colon.col = n)
    (h_flow : sc_colon.inFlow = false)
    (hpre : scanNextToken_preprocess s = .ok (some (sc_colon, ':')))
    (hcorr_colon : ScannerSurfCorr sc_colon sp_colon)
    (hcolon : scanValue sc_colon = .ok sc_after) :
    ∃ sp_after, ScannerSurfCorr sc_after sp_after ∧
      TPendingNode start false sp_block sp_after ec (eo ++ ek) [] ∧
      TPendingNode.ContentPark start sp_after vc ec (n + 1) (eo ++ ek) := by
  rcases park with ⟨gram, hq, hcorr, hrun, hg, hkey, route⟩
  classical
  obtain ⟨sp_mid, sp_ws, sp_prep2, hland, hws, _, hcorr2, hpk, hsuf⟩ :=
    L4YAML.Proofs.StreamAccum.preprocess_some_ssl_comments_landing
      s scan sc_colon ':' hcorr hpre hrun hg
  have hp := L4YAML.Proofs.StreamAccum.preprocess_some_peek hpre
  have h_eq : sp_prep2 = sp_ws := by
    rcases hpk with h | h
    · exact h
    · rw [hp] at h
      cases h
  have h_pe : sp_colon = sp_ws :=
    (ScannerSurfCorr_unique hcorr_colon hcorr2).trans h_eq
  rw [← h_pe] at hws
  rcases hland with hland | hflat
  · have hi : SIndent n sp_mid sp_colon := by
      rcases L4YAML.Proofs.StreamAccum.gstar_white_sIndent_or_tab hws with ⟨k, hk⟩ | htab
      · have hw := L4YAML.Proofs.StreamAccum.SIndent_col hk
        have hz := hland.2.1
        have he : k = n := by omega
        simpa [he] using hk
      · have hsuf' : sp_mid.chars <:+ sc_colon.input.toList := by
          rw [preprocess_input hpre]
          exact hsuf.trans (corr_chars_suffix hcorr)
        have ht := tabIndent_scans_of_located hcorr_colon hsuf' hland.2.1 hws htab
        exact False.elim (scanValue_tab_ne h_flow ht.2 hcolon)
    obtain ⟨sp_after, hc, hc_after⟩ := scanValue_prod sc_colon sp_colon hcorr_colon hp sc_after hcolon
    have hclose : ∀ sp ev_v, TBlockNode (n + 1) .blockOut sp_after sp ev_v →
        TLYamlStream start sp (ec ++ (eo ++ ek) ++ ev_v) := by
      intro sp ev_v hv
      have he : TBlockMapEntry n q sp (ek ++ ev_v) :=
        .explicit n q after sp_mid sp_colon sp_after sp ek ev_v hq (hkey sp_mid hland.1)
          hi hc (.node n .blockOut _ _ _ hv)
      simpa [List.append_assoc] using route sp (ek ++ ev_v) he
    exact ⟨sp_after, hc_after, .pendingMapValue sp_block sp_after n ec (eo ++ ek) hclose,
      .mapValue n (eo ++ ek) hclose⟩
  · obtain ⟨ws, _, _, hcolrun⟩ := gstar_sswhite_run hws
    have hmid := hflat.1
    rw [hmid] at hcolrun
    exfalso
    omega

#print axioms question_park_from_scan
#print axioms explicit_scalar_content_step
#print axioms retained_key_to_owner_value_park
end L4YAML.Tests.Guards.OwnerExplicitKeyPark
