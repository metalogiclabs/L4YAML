module
public import Tests.Guards.Proofs.OwnerExplicitKeyPark
public section
namespace L4YAML.Tests.Guards.OwnerExplicitKeyFold
open L4YAML L4YAML.Scanner L4YAML.Surface
open L4YAML.Proofs.Serialization.SerializationWellFormed
open L4YAML.Proofs.Serialization.TraceOf
open L4YAML.Proofs.Serialization.TraceOf.DocBridge
open L4YAML.Proofs.Serialization.TraceOf.StreamBridge
open L4YAML.Proofs.Serialization.TraceOf.ContentBridge
open L4YAML.Proofs.CouplingBridge
open L4YAML.Tests.Guards.OwnerExplicitKeyPark

/-- The actual matched-colon route is consumed by the owner's TPendingNode,
    with the TSLYamlStream coupling at exactly the same returned scanner state.
    The remaining native token/event transport is an explicit premise, not an
    assumed theorem about all scanner states. -/
lemma matched_colon_owner_fold
    {start q after scan sp_colon sp_block : SurfPos} {n : Nat}
    {s sc_colon sc_after : ScannerState} {vc : Char} {ec eo ek : List Event}
    (hS : TSLYamlStream start s sp_block ec (eo ++ ek) [])
    (park : KeyReady start q after scan n s ec eo ek)
    (h_deeper : n < scan.col) (h_colon_col : sp_colon.col = n)
    (h_flow : sc_colon.inFlow = false)
    (hpre : scanNextToken_preprocess s = .ok (some (sc_colon, ':')))
    (hcorr_colon : ScannerSurfCorr sc_colon sp_colon)
    (hcolon : scanValue sc_colon = .ok sc_after)
    (htrace : PushesTrace s.tokens sc_after.tokens []) :
    ∃ sp_after, ScannerSurfCorr sc_after sp_after ∧
      TSLYamlStream start sc_after sp_block ec (eo ++ ek) [] ∧
      TPendingNode start false sp_block sp_after ec (eo ++ ek) [] ∧
      TPendingNode.ContentPark start sp_after vc ec (n + 1) (eo ++ ek) := by
  obtain ⟨sp_after, hcorr, hp, hc⟩ :=
    retained_key_to_owner_value_park (vc := vc) park h_deeper h_colon_col
      h_flow hpre hcorr_colon hcolon
  refine ⟨sp_after, hcorr, ⟨hS.stream, ?_⟩, hp, hc⟩
  rw [htrace.goOut_at [], hS.events]
  simp

#print axioms matched_colon_owner_fold
end L4YAML.Tests.Guards.OwnerExplicitKeyFold
