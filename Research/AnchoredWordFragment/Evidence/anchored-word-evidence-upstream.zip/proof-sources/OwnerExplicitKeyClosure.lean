module
public import Tests.Guards.Proofs.OwnerExplicitKeyPark
public import L4YAML.Proofs.Scanner.ScanStrictCoupling
public section
set_option maxHeartbeats 4000000
namespace L4YAML.Tests.Guards.OwnerExplicitKeyClosure
open L4YAML L4YAML.Surface L4YAML.Scanner
open L4YAML.Proofs.CloseStaleExplicitKey
open L4YAML.Proofs.CouplingBridge L4YAML.Proofs.ScannerCoupling
open L4YAML.Proofs.ScalarCoupling L4YAML.Proofs.StructureCoupling
open L4YAML.Proofs.ScanStrictCoupling
open L4YAML.Proofs.BlockScalarFlowGuard L4YAML.Proofs.FlowAdjacency
open L4YAML.Proofs.Serialization.SerializationWellFormed
open L4YAML.Proofs.Serialization.TokenEvents
open L4YAML.Proofs.Serialization.TraceOf
open L4YAML.Proofs.Serialization.TraceOf.DocBridge
open L4YAML.Proofs.Serialization.TraceOf.StreamBridge
open L4YAML.Proofs.PreprocessProduction L4YAML.Proofs.ScannerWhitespace
open L4YAML.Proofs.StreamAccum (white_prepend_SSLComments)
open L4YAML.Tests.Guards.OwnerExplicitKeyPark

-- Replay the previously qualified actual EOF producer on the exact owner source.
lemma preprocess_none_reachable_eof (sc : ScannerState) (sp : SurfPos)
    (hcorr : ScannerSurfCorr sc sp)
    (hok : scanNextToken_preprocess sc = .ok none) :
    ∃ (e : ScannerState) (p : SurfPos), skipToContent sc = .ok e ∧
      ScannerSurfCorr e p ∧ ¬ e.hasMore ∧ p.chars = [] := by
  unfold scanNextToken_preprocess at hok
  simp only [bind, Except.bind, pure, Except.pure] at hok
  split at hok
  · cases hok
  · rename_i s_content h_skip
    split at hok
    · rename_i h_hasMore
      obtain ⟨sp_c, hcorr_c⟩ := skipToContentLoop_ok_corr sc sp _ s_content hcorr
        (Nat.le_refl _) h_skip
      have h_not_lt : ¬ s_content.offset < s_content.inputEnd := by
        simp [ScannerState.hasMore] at h_hasMore; omega
      refine ⟨s_content, sp_c, h_skip, hcorr_c, ?_, eof_corr s_content sp_c hcorr_c h_not_lt⟩
      simpa [ScannerState.hasMore] using h_not_lt
    · rename_i h_hasMore
      split at hok
      · split at hok
        · cases hok
        · split at hok
          · rename_i h_indent h_no_trailing h_peek_none
            exfalso; rw [closeStaleExplicitKey_peek, saveSimpleKey_peek] at h_peek_none
            unfold ScannerState.peek? at h_peek_none; dsimp only [] at h_peek_none
            unfold unwindIndents at h_peek_none
            simp only [unwindIndentsLoop_offset, unwindIndentsLoop_inputEnd,
              unwindIndentsLoop_input] at h_peek_none
            split at h_peek_none
            · cases h_peek_none
            · rename_i h_not_lt; simp [ScannerState.hasMore] at h_hasMore
              exact h_not_lt h_hasMore
          · cases hok
      · split at hok
        · cases hok
        · split at hok
          · rename_i h_no_indent h_no_trailing h_peek_none
            exfalso; rw [closeStaleExplicitKey_peek, saveSimpleKey_peek] at h_peek_none
            unfold ScannerState.peek? at h_peek_none
            split at h_peek_none
            · cases h_peek_none
            · rename_i h_not_lt; simp [ScannerState.hasMore] at h_hasMore
              exact h_not_lt h_hasMore
          · cases hok

lemma next_none_reachable_eof (sc : ScannerState) (sp : SurfPos)
    (hcorr : ScannerSurfCorr sc sp)
    (hok : scanNextToken sc = .ok none) :
    ∃ (e : ScannerState) (p : SurfPos), skipToContent sc = .ok e ∧
      ScannerSurfCorr e p ∧ ¬ e.hasMore ∧ p.chars = [] := by
  unfold scanNextToken at hok
  simp only [bind, Except.bind, pure, Except.pure] at hok
  split at hok
  · simp at hok
  · split at hok
    · rename_i h_pre
      exact preprocess_none_reachable_eof sc sp hcorr h_pre
    · -- §9.2 dangling-node check (item 133)
      split at hok
      · simp at hok
      -- §8.1 flow-value floor (item 172)
      split at hok
      · simp at hok
      split at hok
      · simp at hok
      · split at hok
        · exact absurd (Except.ok.inj hok) nofun
        · -- pending-directives check (Fix B)
          split at hok
          · simp at hok
          -- §9.2 bare-document check (item 132)
          split at hok
          · simp at hok
          · split at hok
            · simp at hok
            · split at hok
              · exact absurd (Except.ok.inj hok) nofun
              · split at hok
                · simp at hok
                · split at hok
                  · exact absurd (Except.ok.inj hok) nofun
                  · -- adjacent-value check (item 47)
                    split at hok
                    · simp at hok
                    · split at hok
                      · simp at hok
                      · exact absurd (Except.ok.inj hok) nofun

/-- A retained explicit key without a value is an explicitEmpty map entry,
    not an incomplete stream. This lemma only constructs the grammar route;
    the native EOF consumer below determines when it may be spent. -/
lemma key_ready_close_ssl {start q after scan endp : SurfPos}
    {n : Nat} {s : ScannerState} {ec eo ek : List Event}
    (park : KeyReady start q after scan n s ec eo ek)
    (hssl : SSLComments scan endp) :
    TLYamlStream start endp (ec ++ eo ++ ek) := by
  rcases park with ⟨gram, hq, hcorr, hrun, hgate, hkey, route⟩
  exact route endp ek (.explicitEmpty n q after endp ek hq
    (hkey endp (white_prepend_SSLComments hrun hssl)))

/-- Native scanner termination is the authority for choosing the no-colon arm.
    Retain the actual skip result and empty source, plus the trace of real tokens. -/
lemma key_ready_close_at_eof {start q after scan sp_block : SurfPos}
    {n : Nat} {s : ScannerState} {ec eo ek : List Event}
    (hS : TSLYamlStream start s sp_block ec (eo ++ ek) [])
    (park : KeyReady start q after scan n s ec eo ek)
    (hstop : scanNextToken s = .ok none) :
    ∃ e sp_end, skipToContent s = .ok e ∧ ¬ e.hasMore ∧ sp_end.chars = [] ∧
      TLYamlStream start sp_end (tokenEvents s.tokens) := by
  rcases park with ⟨gram, hq, hcorr, hrun, hgate, hkey, route⟩
  obtain ⟨e, p, hskip, _, heof, _⟩ := next_none_reachable_eof s scan hcorr hstop
  obtain ⟨sp_end, hfrom, hchars, h_ok⟩ :=
    L4YAML.Proofs.PreprocessProduction.skipToContent_eof_ssl_comments s scan e hcorr hskip heof
  have hssl := L4YAML.Proofs.PreprocessProduction.SSLCommentsFrom_at_park hcorr hrun hgate hfrom h_ok
  refine ⟨e, sp_end, hskip, heof, hchars, ?_⟩
  rw [hS.total]
  simpa [List.append_assoc] using route sp_end ek
    (TBlockMapEntry.explicitEmpty n q after sp_end ek hq (hkey sp_end hssl))

/-- A real nonmatching landing at or left of the key's level closes the entry
    at the pre-indentation grammar endpoint, not at an invented suffix.
    This leaves the next token and its fold transition to the caller. -/
lemma key_ready_close_before_next {start q after scan sp_next sp_block : SurfPos}
    {n : Nat} {s next : ScannerState} {c : Char} {ec eo ek : List Event}
    (hS : TSLYamlStream start s sp_block ec (eo ++ ek) [])
    (park : KeyReady start q after scan n s ec eo ek)
    (h_deeper : n < scan.col)
    (hpre : scanNextToken_preprocess s = .ok (some (next, c)))
    (hcorr_next : ScannerSurfCorr next sp_next)
    (hcol : sp_next.col ≤ n)
    (h_nonmatch : c ≠ ':' ∨ sp_next.col ≠ n)
    (h_not_tab : c ≠ '\t') :
    ∃ sp_mid, sp_mid.col = 0 ∧ GStar SSWhite sp_mid sp_next ∧
      TLYamlStream start sp_mid (tokenEvents s.tokens) := by
  rcases park with ⟨gram, hq, hcorr, hrun, hg, hkey, route⟩
  classical
  obtain ⟨sp_mid, sp_ws, sp_prep2, hland, hws, _, hcorr2, hpk, hsuf⟩ :=
    L4YAML.Proofs.StreamAccum.preprocess_some_ssl_comments_landing
      s scan next c hcorr hpre hrun hg
  have hp := L4YAML.Proofs.StreamAccum.preprocess_some_peek hpre
  have h_eq : sp_prep2 = sp_ws := by
    rcases hpk with h | h
    · exact h
    · rw [hp] at h
      cases h
  have h_pe : sp_next = sp_ws :=
    (ScannerSurfCorr_unique hcorr_next hcorr2).trans h_eq
  rw [← h_pe] at hws
  rcases hland with hland | hflat
  · refine ⟨sp_mid, hland.2.1, hws, ?_⟩
    rw [hS.total]
    simpa [List.append_assoc] using route sp_mid ek
      (TBlockMapEntry.explicitEmpty n q after sp_mid ek hq (hkey sp_mid hland.1))
  · have hcolrun := L4YAML.Proofs.PreprocessProduction.gstar_sswhite_col_ge sp_mid sp_next hws
    have hmid := hflat.1
    rw [hmid] at hcolrun
    exfalso
    omega

#print axioms key_ready_close_ssl
#print axioms key_ready_close_at_eof
#print axioms key_ready_close_before_next
end L4YAML.Tests.Guards.OwnerExplicitKeyClosure
