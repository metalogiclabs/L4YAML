module
public import Tests.Guards.Proofs.OwnerExplicitKeyClosure
public import Tests.Guards.Proofs.OwnerExplicitKeyContent
public meta import Tests.Guards.Proofs.OwnerExplicitKeyClosure
public meta import Tests.Guards.Proofs.OwnerExplicitKeyContent
public import Tests.Guards.Proofs.OwnerExplicitKeyConsume
public meta import Tests.Guards.Proofs.OwnerExplicitKeyConsume
public import Lean.Meta.Native
public meta import Lean
set_option compiler.relaxedMetaCheck true
@[expose] public section Blanket
namespace L4YAML.Tests.Guards.OwnerKeyReplayAudit
open Lean
open L4YAML.Tests.Guards.OwnerExplicitKeyPark
open L4YAML.Tests.Guards.OwnerExplicitKeyClosure
open L4YAML.Tests.Guards.OwnerExplicitKeyContent

-- Replay policy verbatim from #371, except namespace and trace class.
-- Source: metalogiclabs/L4YAML@46283c63ceb82e3ceb16e19a7a4e802ba844a777
-- Blob: 7f7d9e3079018c8486ed85d1640247c758971e72
/-- Axioms admitted without replay. All other dependencies, including private
    and generated-looking names, must pass `replayBooleanAxiom`. -/
def allowedCapstoneAxioms : List Name :=
  [``propext, ``Classical.choice, ``Quot.sound]

initialize registerTraceClass `L4YAML.ownerKeyAxiomReplay

/-- Validate the proposition of a nonstandard Boolean axiom independently of
    its name. Lean 4.36's `nativeEqTrue` records an ordinary `Eq Bool e true`
    axiom and an optional source range; neither authenticates tactic origin.

    The claim must be closed and its transitive axiom dependencies must be
    only itself and the standard foundations. In particular a computation
    carrying an arbitrary proof assumption is rejected before evaluation.
    First try a fresh kernel-checked reflexivity proof (with kernel checking
    forced on and a small finite budget). If opacity or cost prevents that,
    replay the closed Boolean
    with Lean's native evaluator, the same additional trust as native_decide.
    The temporary declaration/environment is discarded. Unreadable claims,
    exceptions, non-Boolean axioms and a false computation fail closed.

    A fabricated but independently true Boolean assertion can pass replay;
    this is claim validation, not a declaration-origin certificate. Callers
    must retain raw axiom counts rather than claim that no axiom was declared. -/
def replayBooleanAxiom (name : Name) : CoreM Bool := withCurrHeartbeats do
  try
    let env := (← getEnv).setExporting false
    -- Read the checked kernel environment, as `collectAxioms` does. During
    -- asynchronous/module elaboration, the public elaborator view can omit
    -- generated axioms even though the checked proof already depends on them.
    let some (.axiomInfo info) := env.toKernelEnv.find? name | do
      trace[L4YAML.ownerKeyAxiomReplay] "unreadable: {name}"
      return false
    if info.isUnsafe then return false
    let .app (.app (.app (.const ``Eq _) (.const ``Bool _)) lhs)
        (.const ``Bool.true _) := info.type | do
      trace[L4YAML.ownerKeyAxiomReplay] "not Boolean: {name}: {info.type}"
      return false
    if lhs.hasFVar || lhs.hasMVar || lhs.hasLooseBVars then return false
    let deps ← collectAxioms name
    unless deps.all (fun a => a == name || allowedCapstoneAxioms.contains a) do
      trace[L4YAML.ownerKeyAxiomReplay] "dependencies: {name}: {deps}"
      return false
    let proofName ← mkFreshUserName `_l4yamlAxiomReplay
    let decl := Declaration.thmDecl {
      name := proofName
      levelParams := info.levelParams
      type := info.type
      value := mkApp2 (mkConst ``Eq.refl [1]) (mkConst ``Bool) lhs
    }
    let opts := debug.skipKernelTC.set (← getOptions) false
    -- Do not spend the full elaboration budget reducing a large finite test
    -- in the kernel before replaying it with the evaluator that produced it.
    let budget := maxHeartbeats.get opts
    let opts := maxHeartbeats.set opts (if budget == 0 then 2000 else min budget 2000)
    match env.toKernelEnv.addDecl opts decl with
    | .ok _ =>
      trace[L4YAML.ownerKeyAxiomReplay] "kernel validated: {name}"
      return true
    | .error _ =>
      trace[L4YAML.ownerKeyAxiomReplay] "native fallback: {name}"
      let result ← ((do
        withoutModifyingEnv do
          setEnv env
          withOptions (debug.skipKernelTC.set · false) do
            Meta.nativeEqTrue `l4yaml_axiom_replay lhs : MetaM Meta.NativeEqTrueResult).run' {} {})
      match result with
      | .success _ =>
        trace[L4YAML.ownerKeyAxiomReplay] "native validated: {name}"
        return true
      | .notTrue => return false
  catch ex =>
    trace[L4YAML.ownerKeyAxiomReplay] "replay exception: {name}: {ex.toMessageData}"
    return false

/-- Per-invocation cache: a shared dependency is replayed once per gate/census.
    It is never reused after an environment or source change. -/
abbrev AxiomReplayM := StateT (NameMap Bool) CoreM

/-- Common admission rule used by the capstone and compiled-environment gates.
    Namespace, private visibility and generated-looking names grant no exemption. -/
def axiomAdmitted (name : Name) : AxiomReplayM Bool := do
  if allowedCapstoneAxioms.contains name then return true
  if let some accepted := (← get).find? name then return accepted
  let accepted ← replayBooleanAxiom name
  modify fun cache => cache.insert name accepted
  return accepted

/-- Unsupported transitive dependencies of a declaration, including assumptions
    outside the declaration's namespace. -/
def unvalidatedAxioms (name : Name) : AxiomReplayM (Array Name) := do
  let axs ← collectAxioms name
  axs.filterM fun a => return !(← axiomAdmitted a)


-- Negative/positive controls are deliberately confined to this audit module.
private axiom falseBoolControl : false = true
private axiom falsePropControl : False
private axiom trueBoolControl : true = true

/-- Run only after loading the compiled module environment with extensions. -/
def auditOwnerKeyAxioms : CoreM (Array String) := (do
    unless (← axiomAdmitted ``trueBoolControl) do
      throwError "positive Boolean control rejected"
    if (← axiomAdmitted ``falseBoolControl) then
      throwError "false Boolean control accepted"
    if (← axiomAdmitted ``falsePropControl) then
      throwError "unsupported proposition control accepted"
    let mut rows : Array String := #["OWNER_KEY_REPLAY_CONTROLS_PASS"]
    let mut leaves : Array Name := #[]
    let names : Array (Name × Nat) := #[( ``question_park_from_scan, 0),
      (``explicit_scalar_content_step, 39), (``retained_key_to_owner_value_park, 0),
      (``key_ready_close_ssl, 0), (``key_ready_close_at_eof, 0), (``key_ready_close_before_next, 0),
      (``explicit_key_content_step, 39), (``props_empty_key_ready, 0), (``props_scalar_key_step, 39),
      (``L4YAML.Tests.Guards.OwnerExplicitKeyConsume.colon_then_content_step, 45)]
    for (n, expected) in names do
      let axs ← collectAxioms n
      let raw := axs.filter fun a => !allowedCapstoneAxioms.contains a
      unless raw.size == expected do
        throwError "owner key axiom census changed for {n}: expected {expected}, got {raw.size}"
      for a in raw do
        unless leaves.contains a do leaves := leaves.push a
      let rejected ← unvalidatedAxioms n
      unless rejected.isEmpty do
        throwError "owner key replay failed for {n}: {rejected}"
      rows := rows.push s!"OWNER_KEY_REPLAY {n}: raw={raw.size} validated={raw.size} rejected=0"
    unless leaves.size == 45 do throwError "owner key axiom union changed: {leaves.size}"
    for a in leaves do rows := rows.push s!"OWNER_KEY_REPLAY_LEAF {a}"
    rows := rows.push s!"OWNER_KEY_REPLAY_UNION raw={leaves.size} validated={leaves.size} rejected=0"
    return rows : AxiomReplayM (Array String)).run' {}

end L4YAML.Tests.Guards.OwnerKeyReplayAudit
end Blanket
