module
public import Tests.Guards.Proofs.OwnerExplicitKeyPark
public import L4YAML.Proofs.Scanner.PropsRunLineCoupling
public section
set_option maxHeartbeats 4000000
namespace L4YAML.Tests.Guards.OwnerExplicitKeyContent
open L4YAML L4YAML.Scanner L4YAML.Surface L4YAML.CharPredicates
open L4YAML.Proofs.Serialization.SerializationWellFormed
open L4YAML.Proofs.Serialization.TraceOf
open L4YAML.Proofs.Serialization.TraceOf.DocBridge
open L4YAML.Proofs.Serialization.TraceOf.StreamBridge
open L4YAML.Proofs.Serialization.TraceOf.ContentBridge
open L4YAML.Proofs.CouplingBridge L4YAML.Proofs.ScannerCoupling
open L4YAML.Proofs.PreprocessIndentStable
open L4YAML.Proofs.StreamAccum (ContentArm NextIsSep SlotGateAt)
open L4YAML.Tests.Guards.OwnerExplicitKeyPark

/-- Property dispatch preserves the actual scanner's cleared indent flag
    and stack, so its park inherits the reading floor. -/
private lemma key_property_floor {m : Nat} {s s' : ScannerState} {c : Char}
    (hc : c = '&' ∨ c = '!') (hp : s.peek? = some c)
    (hd : scanNextToken_dispatchContent s c = .ok s')
    (hn : s.needIndentCheck = false) (hf : m ≤ minContentIndentOf s) :
    IndentFloor s' m := by
  have hi := dispatchContent_props_indents hc hd
  have hnic : s'.needIndentCheck = s.needIndentCheck := by
    rcases hc with he | he
    · subst c
      exact (L4YAML.Proofs.PropsRunLineCoupling.dispatchContent_anchor_line_nic hp hd).2
    · subst c
      exact (L4YAML.Proofs.PropsRunLineCoupling.dispatchContent_tag_line_nic hp hd).2
  exact ⟨hnic.trans hn, by rw [minContentIndentOf_congr hi]; exact hf⟩

/-- The property belongs to the deferred key, never a completed document. -/
inductive KeyProps (start q after scan : SurfPos) (n : Nat)
    (s : ScannerState) (ec eo ep : List Event) : Prop where
  | held (sp_p : SurfPos)
      (hq : GLit '?' q after)
      (hcorr : ScannerSurfCorr s scan)
      (hsep : SSeparate (n + 1) .flowOut after sp_p)
      (hprops : TCNsProperties (n + 1) .flowOut sp_p scan ep)
      (hnext : NextIsSep s)
      (hfloor : IndentFloor s (n + 1))
      (hcol : n + 1 ≤ scan.col)
      (route : ∀ sp ev, TBlockMapEntry n q sp ev → TLYamlStream start sp (ec ++ eo ++ ev)) :
      KeyProps start q after scan n s ec eo ep

inductive KeyProgress (start q after scan : SurfPos) (n : Nat)
    (s : ScannerState) (ec eo ek : List Event) : Prop where
  | ready : KeyReady start q after scan n s ec eo ek → KeyProgress start q after scan n s ec eo ek
  | props : KeyProps start q after scan n s ec eo ek → KeyProgress start q after scan n s ec eo ek

/-- Every content arm preserves the deferred-key route and exact event
    suffix. The alias and block-scalar gates are read from the native
    dispatch itself, rather than supplied as extra caller assumptions. -/
lemma explicit_key_content_step
    {start q after sp_block sp_prep sp_a : SurfPos}
    {n : Nat} {sc s_prep s_ad s' : ScannerState} {c : Char} {ec eo : List Event}
    (hS : TSLYamlStream start s_ad sp_block ec eo [])
    (park : QuestionPark start q after n sc ec eo)
    (h_ad : s_ad = if s_prep.allowDirectives then
      { s_prep with allowDirectives := false, documentEverStarted := true } else s_prep)
    (hcorr_prep : ScannerSurfCorr s_prep sp_prep)
    (hcorr' : ScannerSurfCorr s' sp_a)
    (h_preprocess : scanNextToken_preprocess sc = .ok (some (s_prep, c)))
    (arm : ContentArm s_ad s' c sp_prep sp_a)
    (h_depth : s_ad.flowLevel = 0)
    (h_dispatch : scanNextToken_dispatchContent s_ad c = .ok s')
    (h_not_doc : s_ad.col = 0 → atDocumentBoundary s_ad = false)
    (h_src : SlotGateAt s_prep) :
    (∃ ek, TSLYamlStream start s' sp_block ec (eo ++ ek) [] ∧
      KeyProgress start q after sp_a n s' ec eo ek) ∨
      L4YAML.Proofs.FlowIndexLift.DedentLanding (n + 1) after sp_prep := by
  have h_col0 : 0 < after.col := by have h := park.col; omega
  have hflow : s_ad.inFlow = false := by unfold ScannerState.inFlow; rw [h_depth]; rfl
  have hcorr_ad : ScannerSurfCorr s_ad sp_prep := by
    rw [h_ad]
    exact L4YAML.Proofs.StreamAccum.corr_of_allowDirectives_update hcorr_prep
  have hpeek : s_ad.peek? = some c := by
    rw [h_ad]
    have := L4YAML.Proofs.StreamAccum.preprocess_some_peek h_preprocess
    split <;> exact this
  have h_gate : (c = '*' ∨ c = '|' ∨ c = '>') → s'.col ≠ 0 →
      ¬ (CommentOk s' ∧ s'.peek? = some '#') := by
    intro hc
    rcases hc with hstar | hbs
    · subst c
      obtain ⟨_, _, ⟨_, hpb, hnw⟩, _⟩ :=
        L4YAML.Proofs.StreamAccum.dispatchContent_aliasNode_prod s_ad sp_prep hcorr_ad hpeek h_dispatch
      exact L4YAML.Proofs.StreamAccum.park_gate_of_peekBack hpb hnw
    · have hp := L4YAML.Proofs.StreamAccum.preprocess_some_peek h_preprocess
      exact L4YAML.Proofs.StreamAccum.blockScalar_park_gate hp (h_ad ▸ h_dispatch) hbs
  rcases TPendingNode.content_sep_of_preprocess h_ad park.floor park.col h_col0 park.next park.corr
      hcorr_prep hcorr' h_preprocess h_not_doc hflow h_dispatch h_src with
    ⟨h_sep, h_fl⟩ | h_ded
  · obtain ⟨ek, hpt, hdisj⟩ := accum_step_content_trace_out arm hcorr_ad hpeek h_depth h_dispatch
    refine Or.inl ⟨ek, ⟨hS.stream, by rw [hpt.goOut_at [], hS.events]; simp⟩, ?_⟩
    have h_scalar : ek = [] → (c ≠ '&' ∧ c ≠ '!' ∧ c ≠ '*') →
        KeyProgress start q after sp_a n s' ec eo ek := fun hev h_value => by
      subst ek
      by_cases hbs : c = '|' ∨ c = '>'
      · obtain ⟨sp_bs, d, h_floor, _, hcorr_bs, h_absorb⟩ :=
          L4YAML.Proofs.StreamAccum.dispatchContent_blockScalar_prod_at s_ad sp_prep hcorr_ad hpeek hbs h_dispatch
        have heq := ScannerSurfCorr_unique hcorr_bs hcorr'
        rw [heq] at h_absorb
        have hn : n + 1 ≤ d := by
          unfold minContentIndentOf at h_fl
          exact Nat.le_trans h_fl h_floor
        refine .ready (.ready sp_a park.question hcorr' (GStar.nil _) (fun _ => h_gate (Or.inr hbs)) ?_ park.route)
        intro sp_mid h_ssl
        exact .node n .blockOut _ _ [] ((h_absorb sp_mid h_ssl).elim
          (fun hl => .blockLiteral (n + 1) .blockOut after sp_prep sp_prep sp_mid [] h_sep (TOpt.none _) (hl (n + 1) hn))
          (fun hf => .blockFolded (n + 1) .blockOut after sp_prep sp_prep sp_mid [] h_sep (TOpt.none _) (hf (n + 1) hn)))
      · obtain ⟨sp_gram, sp_res, hT, hws, hgate, hcorr_res⟩ :=
          content_leaf_at_retained (n + 1) hcorr_ad hpeek hflow h_not_doc
            h_value.1 h_value.2.2 h_value.2.1 (fun h => hbs (Or.inl h)) (fun h => hbs (Or.inr h))
            h_dispatch h_fl
        obtain rfl : sp_res = sp_a := ScannerSurfCorr_unique hcorr_res hcorr'
        refine .ready (.ready sp_gram park.question hcorr' hws hgate ?_ park.route)
        intro sp_mid h_ssl
        exact .node n .blockOut _ _ []
          (.flowInBlock (n + 1) .blockOut _ _ _ _ [] h_sep (.content _ _ _ _ _ hT) h_ssl)
    rcases hdisj with ⟨hev, -, -, -, -, hv⟩ | ⟨hev, hc, -⟩ | ⟨hev, hc, -⟩ |
        ⟨hc, ha, hn⟩ | ⟨hc, ht, hn⟩ | ⟨hc, hal⟩
    · exact h_scalar hev hv
    · exact h_scalar hev (by rcases hc with h | h <;> subst h <;> decide)
    · exact h_scalar hev (by rcases hc with h | h <;> subst h <;> decide)
    · have hnic_p := L4YAML.Proofs.PropsRunLineCoupling.preprocess_some_needIndentCheck_false park.noflow h_preprocess
      have hnic_a : s_ad.needIndentCheck = false := by
        rw [h_ad]
        split <;> exact hnic_p
      have hf := key_property_floor (Or.inl hc) hpeek h_dispatch hnic_a h_fl
      have hcp := L4YAML.Proofs.StreamAccum.separate_col_ge h_sep park.col
      have hcs := Nat.le_trans hcp (Nat.le_of_lt (L4YAML.Proofs.StreamAccum.anchorProperty_col_lt ha.1))
      exact .props (.held sp_prep park.question hcorr' h_sep
        (by simpa using TCNsProperties.anchorFirst sp_prep sp_a sp_a ek [] ha (TOpt.none _))
        hn hf hcs park.route)
    · have hnic_p := L4YAML.Proofs.PropsRunLineCoupling.preprocess_some_needIndentCheck_false park.noflow h_preprocess
      have hnic_a : s_ad.needIndentCheck = false := by
        rw [h_ad]
        split <;> exact hnic_p
      have hf := key_property_floor (Or.inr hc) hpeek h_dispatch hnic_a h_fl
      have hcp := L4YAML.Proofs.StreamAccum.separate_col_ge h_sep park.col
      have hcs := Nat.le_trans hcp (Nat.le_of_lt (L4YAML.Proofs.StreamAccum.tagProperty_col_lt ht.1))
      exact .props (.held sp_prep park.question hcorr' h_sep
        (by simpa using TCNsProperties.tagFirst sp_prep sp_a sp_a ek [] ht (TOpt.none _))
        hn hf hcs park.route)
    · refine .ready (.ready sp_a park.question hcorr' (GStar.nil _)
        (fun _ => h_gate (Or.inl hc)) ?_ park.route)
      intro sp_mid h_ssl
      exact .node n .blockOut _ _ ek
        (.flowInBlock (n + 1) .blockOut _ _ _ _ ek h_sep (.alias _ _ _ _ _ hal) h_ssl)
  · exact Or.inr h_ded

/-- A held property may describe an empty key, but its event is retained. -/
lemma props_empty_key_ready {start q after scan : SurfPos}
    {n : Nat} {s : ScannerState} {ec eo ep : List Event}
    (park : KeyProps start q after scan n s ec eo ep) :
    KeyReady start q after scan n s ec eo ep := by
  rcases park with ⟨sp_p, hq, hc, hs, hp, hn, _, _, route⟩
  refine .ready scan hq hc (GStar.nil _) (fun _ _ => NextIsSep.gate hn) ?_ route
  intro sp_mid h_ssl
  exact .node n .blockOut _ _ ep
    (.flowInBlock (n + 1) .blockOut _ _ _ _ ep hs (.propsEmpty _ _ _ _ _ hp) h_ssl)

/-- Scalar content after an anchor/tag belongs to that key. The scalar is
    silent while the property events remain in the scanner and grammar.
    The actual preprocessing supplies separation or a distinct dedent. -/
lemma props_scalar_key_step
    {start q after scan sp_block sp_prep sp_a : SurfPos}
    {n : Nat} {sc s_prep s_ad s' : ScannerState} {c : Char} {ec eo ep : List Event}
    (hS : TSLYamlStream start s_ad sp_block ec (eo ++ ep) [])
    (park : KeyProps start q after scan n sc ec eo ep)
    (h_ad : s_ad = if s_prep.allowDirectives then
      { s_prep with allowDirectives := false, documentEverStarted := true } else s_prep)
    (hcorr_prep : ScannerSurfCorr s_prep sp_prep)
    (hcorr' : ScannerSurfCorr s' sp_a)
    (h_preprocess : scanNextToken_preprocess sc = .ok (some (s_prep, c)))
    (arm : ContentArm s_ad s' c sp_prep sp_a)
    (h_depth : s_ad.flowLevel = 0)
    (h_dispatch : scanNextToken_dispatchContent s_ad c = .ok s')
    (h_not_doc : s_ad.col = 0 → atDocumentBoundary s_ad = false)
    (h_amp : c ≠ '&') (h_star : c ≠ '*') (h_bang : c ≠ '!')
    (h_pipe : c ≠ '|') (h_gt : c ≠ '>')
    (h_src : SlotGateAt s_prep) :
    (TSLYamlStream start s' sp_block ec (eo ++ ep) [] ∧
      KeyReady start q after sp_a n s' ec eo ep) ∨
      L4YAML.Proofs.FlowIndexLift.DedentLanding (n + 1) scan sp_prep := by
  rcases park with ⟨sp_p, hq, hc, hs, hprops, hn, hf, hcol, route⟩
  have hflow : s_ad.inFlow = false := by unfold ScannerState.inFlow; rw [h_depth]; rfl
  have hcorr_ad : ScannerSurfCorr s_ad sp_prep := by
    rw [h_ad]; exact L4YAML.Proofs.StreamAccum.corr_of_allowDirectives_update hcorr_prep
  have hpeek : s_ad.peek? = some c := by
    rw [h_ad]
    have := L4YAML.Proofs.StreamAccum.preprocess_some_peek h_preprocess
    split <;> exact this
  rcases TPendingNode.content_sep_of_preprocess h_ad hf hcol (by omega) hn hc
      hcorr_prep hcorr' h_preprocess h_not_doc hflow h_dispatch h_src with
    ⟨h_sep, h_fl⟩ | h_ded
  · obtain ⟨sp_gram, sp_res, hT, hws, hgate, hcorr_res⟩ :=
      content_leaf_at_retained (n + 1) hcorr_ad hpeek hflow h_not_doc
        h_amp h_star h_bang h_pipe h_gt h_dispatch h_fl
    obtain rfl : sp_res = sp_a := ScannerSurfCorr_unique hcorr_res hcorr'
    obtain ⟨ev_n, hpt, hdisj⟩ := accum_step_content_trace_out arm hcorr_ad hpeek h_depth h_dispatch
    have hev : ev_n = [] := by
      rcases hdisj with ⟨hev, -⟩ | ⟨hev, -⟩ | ⟨hev, -⟩ | ⟨hc, -⟩ | ⟨hc, -⟩ | ⟨hc, -⟩
      · exact hev
      · exact hev
      · exact hev
      · exact absurd hc h_amp
      · exact absurd hc h_bang
      · exact absurd hc h_star
    subst ev_n
    refine Or.inl ⟨⟨hS.stream, by rw [hpt.goOut_at [], hS.events]; simp⟩,
      .ready sp_gram hq hcorr' hws hgate ?_ route⟩
    intro sp_mid h_ssl
    exact .node n .blockOut _ _ ep
      (.flowInBlock (n + 1) .blockOut _ _ _ _ ep hs
        (by simpa using TFlowNode.propsContent (n + 1) .flowOut sp_p scan sp_prep sp_gram ep [] hprops h_sep hT)
        h_ssl)
  · exact Or.inr h_ded

#print axioms explicit_key_content_step
#print axioms props_empty_key_ready
#print axioms props_scalar_key_step
end L4YAML.Tests.Guards.OwnerExplicitKeyContent
