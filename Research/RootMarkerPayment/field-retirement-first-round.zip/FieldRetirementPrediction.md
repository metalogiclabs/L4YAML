# Complete pendingContent value-pack retirement: first-round price

This is a compiler pricing experiment, not a theorem or refutation. Start from
the state-linked candidate already qualified in run 45715345949 on owner
cc830190, not from the separate root/marker submission candidate.

Before changing the field, the unchanged native controls passed: 180 source
strings, 1,110 accepted explicit values, 930 multiple-mark cases and 3,660 steps.

Change only pendingContent.h_vpack from P-or-PackAlt to P. Fix its mechanical
consumer conversion in accum_block_pending by supplying Or.inl to the existing
helper; do not change a producer, add a hypothesis, admission or scannerDrop use.

Prediction: the existing optional source funders prevent direct retirement.
Capture the first real constructor failures and restore all bytes after the
compiler run. Error count is a lower bound, not a closure fixpoint or proof that
the desired stronger invariant is false.
