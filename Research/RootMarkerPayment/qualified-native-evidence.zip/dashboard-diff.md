## Pins moved against `HEAD`

| kind | moved | reading |
|---|---:|---|
| directed (roster fields with a goal) | 3 | toward 3, not toward 0 |
| population (readings without a target) | 21 | consumer-set sizes, holder counts, thread lengths — no direction |

| census | field | before → after | goal | left before → after | move | verdict |
|---|---|---|---:|---|---|---|
| `RelaySupplyCensus` | `DECLINE` | 237 → 236 | 0 | 237 → 236 | shrink-only | toward |
| `ValueLinePacks` | `punt` | 19 → 18 | 0 | 19 → 18 | shrink-only | toward |
| `RouteShapes` | `punt` | 70 → 69 | 0 | 70 → 69 | shrink-only | toward |

<details><summary>population moves</summary>

- `CloseStackCover.expectedLine` nodes 125681 → 125693
- `HypothesisReaderCensus.expectedModuleTally` RELAY 2913 → 2914
- `OrTrueAudit.expectedSummary` paid 24 → 25
- `OrTrueAudit.expectedSummary` relayed 119 → 118
- `PaidLeafDelta.expectedLine` nodes 125681 → 125693
- `PaidLeafDelta.expectedLine` floorNodes 34958 → 34959
- `PremiseNecessityCensus.expectedModuleTallyP` RELAY 2705 → 2706
- `PuntCoverInputs.expectedLine` nodes 125681 → 125693
- `RelaySupplyCensus.expectedTally` PAY 50 → 51
- `RouteShapes.expectedLine` closed 11 → 12
- `ValueLineOrigins.expectedLine` stamp 40 → 39
- `ValueLineOrigins.expectedLine` built 153 → 154
- `ValueLineOrigins.expectedLine` relayedAbsurd 4 → 5
- `ValueLineOrigins.expectedLine` lets 756 → 761
- `ValueLineOrigins.expectedLine` alts 5676 → 5684
- `ValueLineOrigins.expectedLine` nodes 14527 → 14538
- `ValueLineOrigins.expectedLine` liteNodes 693938 → 694503
- `ValueLinePacks.expectedLine` other 6 → 7
- `ValueLinePacks.expectedLine` none 15 → 16
- `ValueLinePacks.expectedLine` touched 149 → 150
- `ValueLinePacks.expectedLine` nodes 14492 → 14503

</details>
