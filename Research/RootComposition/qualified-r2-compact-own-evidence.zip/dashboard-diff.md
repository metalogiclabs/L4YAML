## Pins moved against `2c00e38e677a3924b6db204f7c8d8f6331899173`

| kind | moved | reading |
|---|---:|---|
| directed (roster fields with a goal) | 0 | toward 0, not toward 0 |
| population (readings without a target) | 14 | consumer-set sizes, holder counts, thread lengths — no direction |

<details><summary>population moves</summary>

- `CloseLandingWidth.expectedLine` spends 20 → 21
- `CloseLandingWidth.expectedLine` spendsN 15 → 16
- `CloseSplitFrames.expectedLine` decisions 145 → 146
- `RelaySupplyCensus.expectedSplitLanding` leaves 412 → 413
- `RelaySupplyCensus.expectedSplitLanding` PAY 195 → 196
- `RelaySupplyCensus.expectedSplitBranch` leaves 412 → 413
- `RelaySupplyCensus.expectedSplitBranch` PAY-free 195 → 196
- `ValueLineOrigins.expectedLine` follows 397 → 398
- `ValueLineOrigins.expectedLine` lets 781 → 782
- `ValueLineOrigins.expectedLine` lapps 1231 → 1234
- `ValueLineOrigins.expectedLine` alts 5728 → 5729
- `ValueLineOrigins.expectedLine` liteNodes 698558 → 698732
- `ValueLinePacks.expectedLine` other 9 → 8
- `ValueLinePacks.expectedLine` alt 8 → 9

</details>
