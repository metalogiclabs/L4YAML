## Pins moved against `4c54da7e3716ab0197b126294474bb2868651402`

| kind | moved | reading |
|---|---:|---|
| directed (roster fields with a goal) | 3 | toward 3, not toward 0 |
| population (readings without a target) | 34 | consumer-set sizes, holder counts, thread lengths — no direction |

| census | field | before → after | goal | left before → after | move | verdict |
|---|---|---|---:|---|---|---|
| `RelaySupplyCensus` | `DECLINE` | 235 → 234 | 0 | 235 → 234 | shrink-only | toward |
| `ValueLinePacks` | `punt` | 17 → 16 | 0 | 17 → 16 | shrink-only | toward |
| `RouteShapes` | `punt` | 70 → 69 | 0 | 70 → 69 | shrink-only | toward |

<details><summary>population moves</summary>

- `CapstonePathAudit.expectedSummary` arms 237 → 239
- `CloseStackCover.expectedLine` nodes 126539 → 126564
- `ConclusionRouteCensus.expectedPipeSplit` landed 100 → 102
- `ConclusionRouteCensus.expectedPipeSplit` landed-producers 10 → 12
- `ConclusionRouteCensus.expectedPipeSplit` total 126 → 128
- `HypothesisReaderCensus.expectedModuleTally` constants 1745 → 1746
- `HypothesisReaderCensus.expectedModuleTally` decls 1389 → 1390
- `HypothesisReaderCensus.expectedModuleTally` READ 1421 → 1423
- `HypothesisReaderCensus.expectedModuleTally` RELAY 2908 → 2910
- `OrTrueAudit.expectedSummary` paid 25 → 26
- `OrTrueAudit.expectedSummary` relayed 118 → 117
- `PaidLeafDelta.expectedLine` nodes 126539 → 126564
- `PaidLeafDelta.expectedLine` floorNodes 34960 → 34999
- `PremiseNecessityCensus.expectedModuleTallyP` constants 1745 → 1746
- `PremiseNecessityCensus.expectedModuleTallyP` decls 1389 → 1390
- `PremiseNecessityCensus.expectedModuleTallyP` READ 1484 → 1486
- `PremiseNecessityCensus.expectedModuleTallyP` RELAY 2700 → 2702
- `PuntCoverInputs.expectedLine` nodes 126539 → 126564
- `RelaySupplyCensus.expectedTally` PAY 50 → 51
- `RelaySupplyCensus.expectedPipeLanding` piped 100 → 102
- `RelaySupplyCensus.expectedPipeLanding` producers 10 → 12
- `RouteShapes.expectedLine` closed 11 → 12
- `ValueLineOrigins.expectedLine` stamp 38 → 37
- `ValueLineOrigins.expectedLine` built 156 → 157
- `ValueLineOrigins.expectedLine` relayedAbsurd 6 → 7
- `ValueLineOrigins.expectedLine` lets 765 → 775
- `ValueLineOrigins.expectedLine` lapps 1231 → 1232
- `ValueLineOrigins.expectedLine` alts 5670 → 5712
- `ValueLineOrigins.expectedLine` nodes 14644 → 14657
- `ValueLineOrigins.expectedLine` liteNodes 693535 → 696789
- `ValueLinePacks.expectedLine` other 6 → 7
- `ValueLinePacks.expectedLine` none 15 → 16
- `ValueLinePacks.expectedLine` touched 152 → 153
- `ValueLinePacks.expectedLine` nodes 14609 → 14622

</details>
