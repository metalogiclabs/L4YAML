## Pins moved against `9f59de2e097d0174f14651d91a88917c026e3acb`

| kind | moved | reading |
|---|---:|---|
| directed (roster fields with a goal) | 0 | toward 0, not toward 0 |
| population (readings without a target) | 7 | consumer-set sizes, holder counts, thread lengths — no direction |

<details><summary>population moves</summary>

- `CapstonePathAudit.expectedSummary` arms 229 → 230
- `CloseLandingWidth.expectedLine` spends 19 → 20
- `CloseLandingWidth.expectedLine` spendsN 14 → 15
- `CloseSplitFrames.expectedLine` decisions 144 → 145
- `ValueLineOrigins.expectedLine` lapps 1229 → 1231
- `ValueLineOrigins.expectedLine` alts 5727 → 5728
- `ValueLineOrigins.expectedLine` liteNodes 698354 → 698558

</details>
