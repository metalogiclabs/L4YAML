## Pins moved against `967d3503b30dde555078929f118101cba9f95a56`

| kind | moved | reading |
|---|---:|---|
| directed (roster fields with a goal) | 7 | toward 7, not toward 0 |
| population (readings without a target) | 62 | consumer-set sizes, holder counts, thread lengths — no direction |

| census | field | before → after | goal | left before → after | move | verdict |
|---|---|---|---:|---|---|---|
| `CapstonePathAudit` | `off` | 179 → 178 | 0 | 179 → 178 | shrink-only | toward |
| `OrTrueAudit` | `positions` | 253 → 252 | 0 | 253 → 252 | shrink-only | toward |
| `OrTrueAudit` | `PackAlt` | 67 → 66 | 0 | 67 → 66 | shrink-only | toward |
| `OrTrueAudit` | `inrTrivial` | 460 → 459 | 0 | 460 → 459 | shrink-only | toward |
| `OrTrueAudit` | `nested` | 91 → 90 | 0 | 91 → 90 | shrink-only | toward |
| `RelaySupplyCensus` | `DECLINE` | 214 → 206 | 0 | 214 → 206 | shrink-only | toward |
| `RelaySupplyCensus` | `DECLINE-free` | 118 → 110 | 0 | 118 → 110 | shrink-only | toward |

<details><summary>population moves</summary>

- `CapstonePathAudit.expectedSummary` positions 253 → 252
- `CapstonePathAudit.expectedSummary` off-honest-nested 15 → 14
- `CapstonePathAudit.expectedSummary` streamAccum-reached 1151/1261 → 1152/1263
- `CapstonePathAudit.expectedSummary` arms 239 → 229
- `CloseLandingWidth.expectedLine` spends 23 → 19
- `CloseLandingWidth.expectedLine` spendsN 18 → 14
- `CloseLandingWidth.expectedLine` handoffs 7 → 5
- `CloseLandingWidth.expectedLine` carries 1 → 0
- `CloseLandingWidth.expectedLine` handInd 6 → 4
- `CloseLandingWidth.expectedLine` handDirect 7 → 5
- `CloseLandingWidth.expectedLine` handCmp 6 → 4
- `CloseSplitFrames.expectedLine` decisions 155 → 144
- `CloseSplitFrames.expectedLine` apps 60 → 59
- `CloseStackCover.expectedLine` nodes 126564 → 127027
- `ConclusionRouteCensus.expectedPipeSplit` landed 102 → 103
- `ConclusionRouteCensus.expectedPipeSplit` total 128 → 129
- `DeadDeclarationCensus.expectedDeadCensus` population 14049 → 14055
- `DeadDeclarationCensus.expectedDeadCensus` thm 10169 → 10175
- `DispatchPrice.expectedSteps` stepHolders 2109 → 2113
- `HypothesisReaderCensus.expectedModuleTally` constants 1746 → 1745
- `HypothesisReaderCensus.expectedModuleTally` decls 1390 → 1388
- `HypothesisReaderCensus.expectedModuleTally` FIELD 175 → 173
- `HypothesisReaderCensus.expectedModuleTally` READ 1423 → 1402
- `HypothesisReaderCensus.expectedModuleTally` RELAY 2910 → 2914
- `NarrowingWorthCensus.expectedNoopTally` theorems 6421 → 6428
- `OpenEntryRoute.expectedLine` chainApps 4 → 3
- `PaidLeafDelta.expectedLine` nodes 126564 → 127027
- `PaidLeafDelta.expectedLine` floorNodes 34999 → 34979
- `PremiseNecessityCensus.expectedModuleTallyP` constants 1746 → 1745
- `PremiseNecessityCensus.expectedModuleTallyP` decls 1390 → 1388
- `PremiseNecessityCensus.expectedModuleTallyP` FIELD 201 → 199
- `PremiseNecessityCensus.expectedModuleTallyP` READ 1486 → 1465
- `PremiseNecessityCensus.expectedModuleTallyP` RELAY 2702 → 2706
- `PuntCoverInputs.expectedLine` nodes 126564 → 127027
- `RelaySupplyCensus.expectedPipeLanding` piped 102 → 103
- `RelaySupplyCensus.expectedSplitLanding` leaves 422 → 412
- `RelaySupplyCensus.expectedSplitLanding` PAY 197 → 195
- `RelaySupplyCensus.expectedSplitBranch` leaves 422 → 412
- `RelaySupplyCensus.expectedSplitBranch` relayRooted 161 → 160
- `RelaySupplyCensus.expectedSplitBranch` siteDecided 14 → 15
- `RelaySupplyCensus.expectedSplitBranch` plainRoot 52 → 51
- `RelaySupplyCensus.expectedSplitBranch` PAY-free 197 → 195
- `ValueLineOrigins.expectedLine` rows 198 → 197
- `ValueLineOrigins.expectedLine` paramRows 94 → 93
- `ValueLineOrigins.expectedLine` built 157 → 156
- `ValueLineOrigins.expectedLine` someHeld 125 → 124
- `ValueLineOrigins.expectedLine` follows 416 → 397
- `ValueLineOrigins.expectedLine` lets 775 → 781
- `ValueLineOrigins.expectedLine` lapps 1232 → 1229
- `ValueLineOrigins.expectedLine` alts 5712 → 5727
- `ValueLineOrigins.expectedLine` nodes 14657 → 14630
- `ValueLineOrigins.expectedLine` liteNodes 696789 → 698354
- `ValueLinePacks.expectedLine` rows 169 → 168
- `ValueLinePacks.expectedLine` paramRows 89 → 88
- `ValueLinePacks.expectedLine` relay 37 → 38
- `ValueLinePacks.expectedLine` chain 55 → 52
- `ValueLinePacks.expectedLine` route 2 → 1
- `ValueLinePacks.expectedLine` other 7 → 9
- `ValueLinePacks.expectedLine` levelVar 57 → 56
- `ValueLinePacks.expectedLine` none 16 → 15
- `ValueLinePacks.expectedLine` touched 153 → 152
- `ValueLinePacks.expectedLine` nodes 14622 → 14595

</details>
