## Pins moved against `HEAD`

| kind | moved | reading |
|---|---:|---|
| directed (roster fields with a goal) | 6 | toward 4, not toward 2 |
| population (readings without a target) | 131 | consumer-set sizes, holder counts, thread lengths — no direction |

| census | field | before → after | goal | left before → after | move | verdict |
|---|---|---|---:|---|---|---|
| `RelaySupplyCensus` | `DECLINE` | 237 → 235 | 0 | 237 → 235 | shrink-only | toward |
| `PremiseNecessityCensus` | `dead` | 33 → 30 | 0 | 33 → 30 | shrink-only | toward |
| `ValueLinePacks` | `punt` | 19 → 17 | 0 | 19 → 17 | shrink-only | toward |
| `ParkBill` | `Tp` | 40 → 39 | 0 | 40 → 39 | shrink-only | toward |
| `RelaySupplyCensus` | `DECLINE` | 213 → 214 | 0 | 213 → 214 | shrink-only | AWAY (owner's word) |
| `RelaySupplyCensus` | `DECLINE-free` | 117 → 118 | 0 | 117 → 118 | shrink-only | AWAY (owner's word) |

<details><summary>population moves</summary>

- `ArmSpendCensus.expectedTally` edges 110 → 102
- `ArmSpendCensus.expectedTally` PAY 17 → 14
- `ArmSpendCensus.expectedTally` RELAY 32 → 30
- `ArmSpendCensus.expectedTally` VIA 32 → 29
- `CapstonePathAudit.expectedSummary` streamAccum-reached 1152/1262 → 1151/1261
- `CapstonePathAudit.expectedSummary` arms 235 → 237
- `CapstonePathAudit.expectedSummary` drop-set 8/8 → 7/8
- `CarrierArmPrice.expectedLine` mentions 45 → 44
- `CloseLandingWidth.expectedLine` spends 24 → 23
- `CloseLandingWidth.expectedLine` spendsC 6 → 5
- `CloseLandingWidth.expectedLine` widthInd 5 → 4
- `CloseLandingWidth.expectedLine` idxDirect 4 → 3
- `CloseLandingWidth.expectedLine` both 4 → 3
- `CloseLandingWidth.expectedLine` empties 30 → 31
- `CloseLandingWidth.expectedLine` emptyInd 14 → 15
- `CloseLandingWidth.expectedLine` emptyCmp 6 → 7
- `CloseLandingWidth.expectedLine` emptySame 2 → 1
- `CloseLandingWidth.expectedLine` reach 38 → 37
- `CloseSplitFrames.expectedLine` asked 6 → 5
- `CloseSplitFrames.expectedLine` both 4 → 3
- `CloseSplitFrames.expectedLine` feedDeferred 2 → 1
- `CloseSplitFrames.expectedLine` entry 4 → 3
- `CloseSplitFrames.expectedLine` entrySBI 4 → 3
- `CloseSplitFrames.expectedLine` closeF 4 → 3
- `CloseSplitFrames.expectedLine` closeFV 4 → 3
- `CloseSplitFrames.expectedLine` top 4 → 3
- `CloseSplitFrames.expectedLine` cover 4 → 3
- `CloseSplitFrames.expectedLine` cover2 4 → 3
- `CloseSplitFrames.expectedLine` floorB 4 → 3
- `CloseSplitFrames.expectedLine` aboveKMem 1 → 0
- `CloseSplitFrames.expectedLine` aboveKEx 1 → 0
- `CloseSplitFrames.expectedLine` decisions 159 → 155
- `CloseSplitFrames.expectedLine` decOnK 22 → 20
- `CloseSplitFrames.expectedLine` decKMem 8 → 6
- `CloseSplitFrames.expectedLine` apps 61 → 60
- `CloseStackCover.expectedLine` eight 8 → 6
- `CloseStackCover.expectedLine` eightPB 4 → 3
- `CloseStackCover.expectedLine` eightPBC 4 → 3
- `CloseStackCover.expectedLine` eightTop 4 → 3
- `CloseStackCover.expectedLine` eightNic 8 → 6
- `CloseStackCover.expectedLine` eightPrep 8 → 6
- `CloseStackCover.expectedLine` eightCover 8 → 6
- `CloseStackCover.expectedLine` nodes 125681 → 126539
- `ConclusionRouteCensus.expectedPipeSplit` producers 28/10 → 26/9
- `ConclusionRouteCensus.expectedPipeSplit` landed 101 → 100
- `ConclusionRouteCensus.expectedPipeSplit` total 129 → 126
- `DeadDeclarationCensus.expectedDeadCensus` population 14050 → 14049
- `DeadDeclarationCensus.expectedDeadCensus` thm 10170 → 10169
- `DispatchPrice.expectedSteps` stepHolders 2108 → 2109
- `FreeSurfaceCensus.expectedCensus` theorems 111 → 110
- `FreeSurfaceCensus.expectedCensus` nestedConcl 63 → 62
- `HypothesisReaderCensus.expectedModuleTally` constants 1747 → 1745
- `HypothesisReaderCensus.expectedModuleTally` decls 1391 → 1389
- `HypothesisReaderCensus.expectedModuleTally` READ 1422 → 1421
- `HypothesisReaderCensus.expectedModuleTally` RELAY 2913 → 2908
- `HypothesisReaderCensus.expectedModuleTally` UNUSED 27 → 24
- `NarrowingWorthCensus.expectedFaceTally` faces 63 → 62
- `NarrowingWorthCensus.expectedNoopTally` theorems 6422 → 6421
- `OpenEntryRoute.expectedLine` reach 38 → 37
- `OrTrueAudit.expectedSummary` paid 24 → 25
- `OrTrueAudit.expectedSummary` relayed 119 → 118
- `PaidLeafDelta.expectedLine` nodes 125681 → 126539
- `PaidLeafDelta.expectedLine` floorNodes 34958 → 34960
- `ParkBill.expectedBill` extra 15 → 14
- `ParkGapProduction.expectedLine` pop 10 → 9
- `ParkGapProduction.expectedLine` sites 13 → 9
- `ParkGapProduction.expectedLine` spend 6 → 3
- `ParkGapProduction.expectedLine` nospend 7 → 6
- `ParkGapProduction.expectedLine` len1 6 → 3
- `ParkGapWidth.expectedPop` pop 10 → 9
- `ParkGapWidth.expectedPop` sites 13 → 9
- `ParkGapWidth.expectedWidth` w1 6 → 3
- `ParkGapWidth.expectedWidth` unreached 5 → 4
- `ParkGapWidth.expectedWidth` corrScan 13 → 9
- `PremiseNecessityCensus.expectedModuleTallyP` constants 1747 → 1745
- `PremiseNecessityCensus.expectedModuleTallyP` decls 1391 → 1389
- `PremiseNecessityCensus.expectedModuleTallyP` READ 1485 → 1484
- `PremiseNecessityCensus.expectedModuleTallyP` RELAY 2705 → 2700
- `PremiseNecessityCensus.expectedModuleTallyP` UNUSED 27 → 24
- `PremiseNecessityCensus.expectedDeadTally` UNUSED 28 → 25
- `ProducerDerivation.expectedCensus` corrHyp 635 → 634
- `ProducerDerivation.expectedCensus` streamConcl 92 → 91
- `ProducerDerivation.expectedCensus` both 45 → 44
- `ProducerDerivation.expectedProdThread` prodThread 24 → 23
- `ProducerDerivation.expectedProdThread` withCorr 19 → 18
- `ProducerDerivation.expectedProdInT` prodOutsideT 9 → 8
- `ProducerDerivation.expectedProdInT` union 28 → 27
- `ProducerDerivation.expectedProdInT` unionOutsideT 9 → 8
- `PuntCoverInputs.expectedLine` nodes 125681 → 126539
- `RelaySupplyCensus.expectedTally` edges 640 → 636
- `RelaySupplyCensus.expectedTally` VIA 28 → 26
- `RelaySupplyCensus.expectedPipeLanding` piped 101 → 100
- `RelaySupplyCensus.expectedPipeLanding` FIELD 38 → 37
- `RelaySupplyCensus.expectedSplitLanding` collapsed 12 → 10
- `RelaySupplyCensus.expectedSplitLanding` leaves 419 → 422
- `RelaySupplyCensus.expectedSplitLanding` PAY 195 → 197
- `RelaySupplyCensus.expectedSplitBranch` leaves 419 → 422
- `RelaySupplyCensus.expectedSplitBranch` PAY-free 195 → 197
- `RelaySupplyCensus.expectedDeclineReach` accounted 640/640 → 636/636
- `RepairChoice.expectedThread` prodThread 24 → 23
- `RouteShapes.expectedLine` routeArgs 183 → 185
- `RouteShapes.expectedLine` routeCarry 69 → 68
- `RouteShapes.expectedLine` routeFwd 55 → 58
- `RouteShapes.expectedLine` builders 13 → 12
- `StreamCompositions.expectedLine` unmarked 157 → 156
- `StreamCompositions.expectedLine` reach 38 → 37
- `ValueLineOrigins.expectedLine` rows 197 → 198
- `ValueLineOrigins.expectedLine` paramRows 93 → 94
- `ValueLineOrigins.expectedLine` stamp 40 → 38
- `ValueLineOrigins.expectedLine` built 153 → 156
- `ValueLineOrigins.expectedLine` heldOrigins 15 → 14
- `ValueLineOrigins.expectedLine` someHeld 124 → 125
- `ValueLineOrigins.expectedLine` relayedAbsurd 4 → 6
- `ValueLineOrigins.expectedLine` follows 412 → 416
- `ValueLineOrigins.expectedLine` lets 756 → 765
- `ValueLineOrigins.expectedLine` lapps 1235 → 1231
- `ValueLineOrigins.expectedLine` alts 5676 → 5670
- `ValueLineOrigins.expectedLine` nodes 14527 → 14644
- `ValueLineOrigins.expectedLine` liteNodes 693938 → 693535
- `ValueLinePacks.expectedLine` rows 168 → 169
- `ValueLinePacks.expectedLine` paramRows 88 → 89
- `ValueLinePacks.expectedLine` empty 0 → 2
- `ValueLinePacks.expectedLine` relay 35 → 37
- `ValueLinePacks.expectedLine` step 11 → 10
- `ValueLinePacks.expectedLine` via 4 → 3
- `ValueLinePacks.expectedLine` alt 7 → 8
- `ValueLinePacks.expectedLine` held 8 → 7
- `ValueLinePacks.expectedLine` levelVar 56 → 57
- `ValueLinePacks.expectedLine` helpers [frameChainUnion → [frameChainUnionD
- `ValueLinePacks.expectedLine` touched 149 → 152
- `ValueLinePacks.expectedLine` nodes 14492 → 14609

</details>
